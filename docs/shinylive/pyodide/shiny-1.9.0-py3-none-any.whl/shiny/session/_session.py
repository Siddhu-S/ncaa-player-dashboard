from __future__ import annotations

__all__ = ("Session", "Inputs", "Outputs", "ClientData")
import asyncio
import contextlib
import dataclasses
import enum
import functools
import json
import os
import re
import sys
import traceback
import typing
import urllib.parse
import warnings
from abc import ABC, abstractmethod
from contextvars import ContextVar
from pathlib import Path
from typing import (
    TYPE_CHECKING,
    Any,
    AsyncIterable,
    Awaitable,
    Callable,
    Generator,
    Iterable,
    Literal,
    Optional,
    Union,
    cast,
    overload,
)

import orjson
from htmltools import TagChild, TagList
from opentelemetry.context import Context as OtelContext
from opentelemetry.trace import Span, Status, StatusCode, set_span_in_context
from starlette.requests import HTTPConnection, Request
from starlette.responses import (
    HTMLResponse,
    PlainTextResponse,
    Response,
    StreamingResponse,
)
from starlette.types import ASGIApp

from .. import _utils, reactive, render
from .._connection import Connection, ConnectionClosed
from .._deprecated import warn_deprecated
from .._docstring import add_example
from .._fileupload import FileInfo, FileUploadManager
from .._namespaces import Id, Root
from .._typing_extensions import NotRequired, TypedDict
from .._utils import wrap_async
from ..bookmark import BookmarkApp, BookmarkProxy
from ..bookmark._button import BOOKMARK_ID
from ..bookmark._restore_state import RestoreContext
from ..bookmark._serializers import serializer_file_input
from ..http_staticfiles import FileResponse
from ..input_handler import input_handlers
from ..module import ResolvedId
from ..otel._attributes import (
    extract_http_attributes,
    extract_source_ref,
    get_session_id_attrs,
)
from ..otel._collect import OtelCollectLevel, _get_env_level
from ..otel._decorators import suppress as otel_suppress
from ..otel._function_attrs import resolve_func_otel_level
from ..otel._labels import create_otel_label, create_otel_span_name
from ..otel._span_wrappers import (
    shiny_otel_span,
    shiny_otel_span_stream,
    start_otel_span,
)
from ..reactive import Effect_, Value, effect, isolate
from ..reactive._core import _enclosing_run, _reactive_environment
from ..render.renderer import Renderer, RendererT
from ..testmode import _snapshot_preprocess_file_input
from ..types import (
    Jsonifiable,
    SafeException,
    SilentCancelOutputException,
    SilentException,
    SilentOperationInProgressException,
)
from ._utils import RenderedDeps, read_thunk_opt, session_context

if TYPE_CHECKING:
    from .._app import App
    from ..bookmark import Bookmark
    from ..bookmark._serializers import Unserializable


REPEAT_OUTPUT_FLUSH_DELAY_SECS = 0.01
"""
How long an output flush requested while a session's flush callbacks run waits to
start. A flush callback that requests one each time it runs (e.g. a `once=False`
`on_flushed` callback that calls `ui.update_*()`) then repeats at most this often,
instead of as fast as the event loop allows.
"""


class ConnectionState(enum.Enum):
    Start = 0
    Running = 1
    Closed = 2


class ProtocolError(Exception):
    message: str

    def __init__(self, message: str = ""):
        super(ProtocolError, self).__init__(message)
        self.message = message


class SessionWarning(RuntimeWarning):
    pass


# By default warnings are shown once; we want to always show them.
warnings.simplefilter("always", SessionWarning)


# This cast is necessary because if the type checker thinks that if
# "tag" isn't in `message`, then it's not a ClientMessage object.
# This will be fixable when TypedDict items can be marked as
# potentially missing, in Python 3.10, with PEP 655.
class ClientMessage(TypedDict):
    method: str


class ClientMessageInit(ClientMessage):
    data: dict[str, object]


class ClientMessageUpdate(ClientMessage):
    data: dict[str, object]


# For messages where "method" is something other than "init" or "update".
class ClientMessageOther(ClientMessage):
    args: list[object]
    tag: int


# This is the type for the function provided by the user to provide the contents of a
# download. It must be a function that takes no arguments, and returns one of:
# 1. A string, which will be interpreted as a path
# 2. A regular Iterable of bytes or strings (i.e. a generator function)
# 3. An AsyncIterable of bytes or strings (i.e. an async generator function)
#
# (Not currently supported is Awaitable[str], could be added easily enough if needed.)
DownloadHandler = Callable[
    [],
    Union[str, Iterable[Union[bytes, str]], AsyncIterable[Union[bytes, str]]],
]

DynamicRouteHandler = Callable[[Request], ASGIApp]


@dataclasses.dataclass
class DownloadInfo:
    filename: Callable[[], str] | str | None
    content_type: Optional[Callable[[], str] | str]
    handler: DownloadHandler
    encoding: str


class OutBoundMessageQueues:
    def __init__(self, record_test_values: bool = False):
        self.values: dict[str, Any] = {}
        self.errors: dict[str, Any] = {}
        self.input_messages: list[dict[str, Any]] = []

        # Test-mode (`SHINY_TESTMODE`) persistent record of the last value/error
        # sent for each output. Unlike `values`/`errors`, these are NOT cleared
        # by `reset()`, so a test snapshot can report the last computed value of
        # every output even though the transient queues are flushed each cycle.
        self._record_test_values = record_test_values
        self.test_values: dict[str, Any] = {}
        self.test_errors: dict[str, Any] = {}
        self.test_tracebacks: dict[str, str] = {}
        """
        Formatted traceback of the last error for each output, in test mode only.

        Deliberately kept out of the outbound error message and out of
        `_build_test_snapshot()`: the former is sent to the browser and the latter
        is served over HTTP, and neither should carry a stack trace. Read
        in-process by `shiny.pytest.test_server`.
        """
        self.test_silent: set[str] = set()
        """
        Outputs whose most recent render produced nothing (a `req()` failure), in
        test mode only.

        `test_values`/`test_errors` keep the *last* value an output computed, so
        without this there is no way to tell that the latest render sent `None`
        to the client and blanked the output. Cleared for an output as soon as it
        computes a value or errors again.
        """

    def is_empty(self) -> bool:
        return not self.values and not self.errors and not self.input_messages

    def reset(self) -> None:
        self.values.clear()
        self.errors.clear()
        self.input_messages.clear()

    def set_value(self, id: str, value: Any) -> None:
        self.values[id] = value
        # remove from self.errors
        if id in self.errors:
            del self.errors[id]
        if self._record_test_values:
            self.test_values[id] = value
            self.test_errors.pop(id, None)
            self.test_tracebacks.pop(id, None)
            self.test_silent.discard(id)

    def set_silent(self, id: str) -> None:
        """
        Record that computing `id`'s value was silently suppressed (e.g. via
        `req()`).

        Unlike `set_value(id, None)`, this leaves `test_values`/`test_errors`
        untouched, so the test-mode snapshot retains the output's last
        computed value or error (matching Shiny for R) instead of reporting
        `None`. The suppression itself is recorded in `test_silent`, which is
        what tells a test that the latest render produced nothing.
        """
        self.values[id] = None
        self.errors.pop(id, None)
        if self._record_test_values:
            self.test_silent.add(id)

    def set_error(self, id: str, error: Any, traceback_text: str = "") -> None:
        self.errors[id] = error
        # remove from self.values
        if id in self.values:
            del self.values[id]
        if self._record_test_values:
            self.test_errors[id] = error
            self.test_tracebacks[id] = traceback_text
            self.test_values.pop(id, None)
            self.test_silent.discard(id)

    def add_input_message(self, id: str, message: dict[str, Any]) -> None:
        self.input_messages.append({"id": id, "message": message})


# ======================================================================================
# Session abstract base class
# ======================================================================================
class Session(ABC):
    """
    Interface definition for Session-like classes, like :class:`AppSession`,
    :class:`SessionProxy`, and :class:`~shiny.express.ExpressStubSession`.
    """

    ns: ResolvedId
    app: App
    id: str
    input: Inputs
    output: Outputs
    clientdata: ClientData

    # Could be done with a weak ref dict from root to all children. Then we could just
    # iterate over all modules and check the `.bookmark_exclude` list of each proxy
    # session.
    bookmark: Bookmark

    @property
    @abstractmethod
    def user(self) -> str | None: ...

    @property
    @abstractmethod
    def groups(self) -> list[str] | None: ...

    # TODO: not sure these should be directly exposed
    _outbound_message_queues: OutBoundMessageQueues
    _downloads: dict[str, DownloadInfo]

    @abstractmethod
    def is_stub_session(self) -> bool:
        """
        Returns whether this is a stub session.

        In the UI-rendering phase of Shiny Express apps, the session context has a stub
        session. This stub session is not a real session; it is there only so that code
        which expects a session can run without raising errors.
        """

    @add_example(example_name="session_close")
    @abstractmethod
    async def close(self, code: int = 1001) -> None:
        """
        Close the session.
        """

    @add_example(example_name="session_allow_reconnect")
    def allow_reconnect(self, value: bool | Literal["force"]) -> None:
        """
        Allow the client to reconnect to a session after a disconnect.

        By default, when the websocket connection between the browser and the server
        drops, Shiny displays the "Disconnected from server" overlay and the client
        gives up. Calling this method with ``True`` tells the client to instead show a
        countdown dialog and attempt to reconnect to its session.

        On a successful reconnect, the browser sends all of its current input values to
        the session on the server, and the server recalculates any outputs and sends
        them back to the client.

        Parameters
        ----------
        value
            One of the following:

            * ``True``: allow the client to reconnect after a disconnect, but only when
              running in a hosting environment (such as Posit Connect or Shiny Server)
              that has reconnections enabled.
            * ``False``: do not allow the client to reconnect. This is the default.
            * ``"force"``: always attempt to reconnect, regardless of what the hosting
              environment reports.

        Note
        ----
        Reconnecting requires the server to keep the session alive after the client
        disconnects, which is a feature of the hosting environment rather than of Shiny
        itself. ``"force"`` exists for testing on a local connection: the client will
        try to reconnect anywhere, but on a plain ``shiny run`` server the attempt
        starts a brand new session rather than resuming the old one.
        """
        if value is not True and value is not False and value != "force":
            raise ValueError(
                f'`value` must be `True`, `False`, or `"force"`, not {value!r}.'
            )
        self._send_message_sync({"allowReconnect": value})

    @abstractmethod
    def _is_closed(self) -> bool:
        """
        Whether the session is being (or has been) torn down because its client
        went away.

        Distinguishes a whole-session close from an explicit
        :meth:`~shiny.Session.destroy` call on a still-running session: on close
        the reactives in the session are left intact, while an explicit
        ``destroy()`` tears them down.
        """

    @abstractmethod
    def _is_hidden(self, name: str) -> bool: ...

    @add_example(example_name="session_on_ended")
    @abstractmethod
    def on_ended(
        self,
        fn: Callable[[], None] | Callable[[], Awaitable[None]],
    ) -> Callable[[], None]:
        """
        Registers a function to be called after the client has disconnected.

        Parameters
        ----------
        fn
            The function to call.

        Returns
        -------
        :
            A function that can be used to cancel the registration.
        """

    @abstractmethod
    def on_destroy(
        self, fn: Callable[[], None] | Callable[[], Awaitable[None]]
    ) -> None:
        """
        Register a callback to run when this session or module scope is destroyed.

        For ``SessionProxy`` (module sessions), destroy callbacks fire when
        ``session.destroy()`` is explicitly called. For ``AppSession`` (root
        sessions), destroy callbacks fire automatically at session end, after
        all ``on_ended`` callbacks have run.

        Note that closing a session is not the same as destroying a scope. An
        explicit ``destroy()`` tears down the scope's reactive values, calcs,
        and effects, so reading one afterwards raises
        ``DestroyedReactiveError``. When the session closes, values and calcs
        are instead left readable at their last value and reclaimed by ordinary
        garbage collection, so async work that outlives the connection does not
        error.

        Parameters
        ----------
        fn
            The function to call on destroy. Can be sync or async.
        """

    @abstractmethod
    async def destroy(self, id: Id | None = None) -> None:
        """
        Destroy this session or module scope, including all descendant scopes.

        Fires all registered destroy callbacks, then removes all namespaced
        state from the session. This does not alter the UI; use
        :func:`~shiny.ui.remove_ui` to remove UI elements.

        Pass an ``id`` to tear down a **child** module scope instead of this
        one. The parent that inserted a module's UI under an ``id`` can tear it
        down by that same ``id`` with ``session.destroy(id)``, without the
        module having to hand anything back:

        ```python
        @reactive.effect
        @reactive.event(input.add)
        def _():
            ui.insert_ui(my_module_ui("editor"), selector="#container")
            my_module_server("editor")

        @reactive.effect
        @reactive.event(input.remove)
        async def _():
            ui.remove_ui(selector="#editor")
            await session.destroy("editor")
        ```

        An explicit ``destroy()`` call cleans up the following categories of
        state. (Session *close* is deliberately gentler with reactives — see
        "Close is not destroy" below.)

        - **Reactive objects** — Effects are stopped, and a run still in progress
          (e.g. paused at an ``await``) is cancelled, so it can't go on to read
          the scope's destroyed values. Calcs and values are invalidated. After destruction, ``get()``/``set()`` on a destroyed
          value raises ``DestroyedReactiveError``; ``is_set()`` returns
          ``False``.
        - **Inputs** — Namespaced input keys and their values are removed.
          A new module with the same namespace gets fresh input values.
        - **Outputs** — Namespaced output entries are removed and their
          render effects are destroyed.
        - **Message handlers, dynamic routes, downloads** — Namespaced
          entries are removed from the root session.

        For ``SessionProxy``, this must be called explicitly (typically after
        removing dynamic module UI). For ``AppSession``, this is called
        automatically at session end, after all ``on_ended`` callbacks — but
        that path skips the reactive teardown above, per "Close is not destroy".

        Idempotent: calling destroy() more than once has no effect.

        Close is not destroy
        --------------------
        The teardown above describes an explicit ``destroy()`` call on a running
        session. When the session itself closes (the browser tab is closed or
        refreshed), reactive values and calcs are **not** destroyed: they are
        left readable at their last value and reclaimed by ordinary garbage
        collection. Effects are still destroyed, since the session can no longer
        flush, and their in-progress runs are cancelled.

        Without this, any async work that outlives the connection — an
        :class:`~shiny.reactive.ExtendedTask` that settles after the user
        refreshes the page, an ``asyncio`` task, a callback scheduled with
        ``loop.call_later()`` — would raise ``DestroyedReactiveError`` on its
        first reactive access. Writes after close are already inert: the
        session's effects are gone and outbound messages are dropped.

        Composability
        -------------
        Every reactive object — values, calcs, and effects — is **scoped** to
        the session (or module session) in which it was created. When you call
        ``destroy()``, only the objects in that scope are torn down; the parent
        session and sibling modules are unaffected.

        This scoping is what makes modules safe to add and remove dynamically.
        Without it, destroying one module could leak callbacks or invalidate
        reactive objects that belong to another part of the app.

        The key rule: **data that must outlive a module should live outside
        it.** If a reactive value is created inside a module, it is destroyed
        with the module. If it is created in the caller's scope and passed in,
        the module can write to it, and the caller can continue reading it
        after the module is destroyed.

        Returning a reactive value from a module works when the module lives
        for the entire session. However, if you plan to call
        ``session.destroy()``, the returned value will be destroyed and can
        no longer be read:

        ```python
        @module.server
        def my_module_server(input, output, session):
            result = reactive.value(0)
            # ... update result ...
            return result

        returned_value = my_module_server("editor")
        await session.destroy()
        returned_value()  # Raises DestroyedReactiveError!
        ```

        Instead, pass a reactive value **into** the module. The value lives
        in the caller's scope and survives destruction:

        ```python
        @module.server
        def my_module_server(input, output, session, result):
            # Module writes to the caller-owned value
            @reactive.effect
            @reactive.event(input.save)
            def _():
                result.set(input.data())

        # Caller creates and owns the value
        saved_data = reactive.value(None)
        my_module_server("editor", result=saved_data)
        # saved_data is still valid after the module is destroyed
        ```

        Parameters
        ----------
        id
            Optional module ``id`` whose child scope should be destroyed. When
            ``None`` (the default), the current scope is destroyed.

        See Also
        --------
        * :func:`~shiny.ui.remove_ui`
        """

    @abstractmethod
    def make_scope(self, id: Id) -> Session: ...

    @abstractmethod
    def root_scope(self) -> Session: ...

    @abstractmethod
    def _process_ui(self, ui: TagChild) -> RenderedDeps: ...

    @abstractmethod
    def send_input_message(self, id: str, message: dict[str, object]) -> None:
        """
        Send an input message to the session.

        Sends a message to an input on the session's client web page; if the input is
        present and bound on the page at the time the message is received, then the
        input binding object's ``receiveMessage(el, message)`` method will be called.
        This method should generally not be called directly from Shiny apps, but through
        friendlier wrapper functions like ``ui.update_text()``.

        Parameters
        ----------
        id
            An id matching the id of an input to update.
        message
            The message to send.
        """

    @abstractmethod
    def _send_insert_ui(
        self, selector: str, multiple: bool, where: str, content: RenderedDeps
    ) -> None: ...

    @abstractmethod
    def _send_remove_ui(self, selector: str, multiple: bool) -> None: ...

    @overload
    @abstractmethod
    def _send_progress(
        self, type: Literal["binding"], message: BindingProgressMessage
    ) -> None:
        pass

    @overload
    @abstractmethod
    def _send_progress(
        self, type: Literal["open"], message: OpenProgressMessage
    ) -> None:
        pass

    @overload
    @abstractmethod
    def _send_progress(
        self, type: Literal["close"], message: CloseProgressMessage
    ) -> None:
        pass

    @overload
    @abstractmethod
    def _send_progress(
        self, type: Literal["update"], message: UpdateProgressMessage
    ) -> None:
        pass

    @abstractmethod
    def _send_progress(self, type: str, message: object) -> None: ...

    @add_example(example_name="session_send_custom_message")
    @abstractmethod
    async def send_custom_message(self, type: str, message: dict[str, object]) -> None:
        """
        Send a message to the client.

        Parameters
        ----------
        type
            The type of message to send.
        message
            The message to send.

        Note
        ----
        Sends messages to the client which can be handled in JavaScript with
        ``Shiny.addCustomMessageHandler(type, function(message){...})``. Once the
        message handler is added, it will be invoked each time ``send_custom_message()``
        is called on the server.
        """

    @abstractmethod
    async def _send_message(self, message: dict[str, object]) -> None: ...

    @abstractmethod
    def _send_message_sync(self, message: dict[str, object]) -> None:
        """
        Same as _send_message, except that if the message isn't too large and the socket
        isn't too backed up, then the message may be sent synchronously instead of
        having to wait until the current task yields (and potentially much longer than
        that, if there is a lot of contention for the main thread).
        """

    @add_example(example_name="session_on_flush")
    @abstractmethod
    def on_flush(
        self,
        fn: Callable[[], None] | Callable[[], Awaitable[None]],
        once: bool = True,
    ) -> Callable[[], None]:
        """
        Register a function to call before this session's next output flush,
        whether or not it has outputs to send.

        A session sends its outputs (values, errors, and input messages) in one
        message once each cycle ends, i.e. once all of its effects have finished. It
        sends them in a task of its own, so a slow callback here (or a slow client)
        delays only this session. Anything the callback queues, such as a
        ``send_input_message()``, goes out in that same message.

        Parameters
        ----------
        fn
            The function to call.
        once
            Whether to call the function only once, or every time this session
            sends its outputs.

        Returns
        -------
        :
            A function that can be used to cancel the registration.
        """

    @add_example(example_name="session_on_flushed")
    @abstractmethod
    def on_flushed(
        self,
        fn: Callable[[], None] | Callable[[], Awaitable[None]],
        once: bool = True,
    ) -> Callable[[], None]:
        """
        Register a function to call after this session's next output flush, whether
        or not it had outputs to send.

        See :meth:`on_flush` for when a session sends its outputs. Anything the
        callback queues, such as a ``ui.update_*()`` call, goes out in one more
        message right after the callbacks, without running them again.

        Parameters
        ----------
        fn
            The function to call.
        once
            Whether to call the function only once, or every time this session
            sends its outputs.

        Returns
        -------
        :
            A function that can be used to cancel the registration.
        """

    @abstractmethod
    async def _unhandled_error(self, e: Exception) -> None: ...

    @abstractmethod
    def download(
        self,
        id: Optional[str] = None,
        filename: Optional[str | Callable[[], str]] = None,
        media_type: None | str | Callable[[], str] = None,
        encoding: str = "utf-8",
    ) -> Callable[[DownloadHandler], None]:
        """
        Deprecated. Please use :class:`~shiny.render.download_button` instead.

        Parameters
        ----------
        id
            The name of the download.
        filename
            The filename of the download.
        media_type
            The media type of the download.
        encoding
            The encoding of the download.

        Returns
        -------
        :
            The decorated function.
        """

    @add_example(example_name="session_dynamic_route")
    @abstractmethod
    def dynamic_route(self, name: str, handler: DynamicRouteHandler) -> str:
        """
        Register a function to call when a dynamically generated, session-specific,
        route is requested.

        Provides a convenient way to serve-up session-dependent values for other
        clients/applications to consume.

        Parameters
        ----------
        name
            A name for the route (used to determine part of the URL path).
        handler
            The function to call when a request is made to the route. This function
            should take a single argument (a :class:`starlette.requests.Request` object)
            and return a :class:`starlette.types.ASGIApp` object.


        Returns
        -------
        :
            The URL path for the route.
        """

    @abstractmethod
    def _export_test_values(self, **kwargs: Callable[[], Any]) -> None:
        """
        Register named values to include in the test-mode snapshot.

        Internal implementation of the public `shiny.testmode.export_test_values()`
        function; call that instead of this method directly.

        Each value must be a zero-argument callable (a plain function/`lambda` or
        a `reactive.calc`); it is evaluated lazily, in a reactive isolate, when a
        test snapshot is requested. Registered values appear under the ``export``
        block of the snapshot returned by the ``dataobj/shinytest`` endpoint.

        Has no effect unless test mode is enabled (``SHINY_TESTMODE=1``), so calls
        can be left in production code. Re-registering a name overwrites it.

        Parameters
        ----------
        **kwargs
            Named zero-argument callables whose return values are exported.

        See Also
        --------
        * `shiny.testmode.export_test_values`
        """

    @abstractmethod
    def get_test_snapshot_url(self) -> str:
        """
        Return the URL of this session's test-mode snapshot endpoint.

        The URL (with a fresh cache-busting `nonce`) points at the
        `dataobj/shinytest` endpoint, which returns a JSON snapshot of this
        session's `input`, `output`, and `export` values. The endpoint only
        responds when test mode is enabled (`SHINY_TESTMODE=1`); otherwise it
        returns a 404.

        Returns
        -------
        :
            The URL path for the snapshot endpoint.
        """

    @abstractmethod
    def set_message_handler(
        self,
        name: str,
        handler: (
            Callable[..., Jsonifiable] | Callable[..., Awaitable[Jsonifiable]] | None
        ),
        *,
        _handler_session: Optional[Session] = None,
    ) -> str:
        """
        Set a client message handler.

        Sets a method that can be called by the client via
        `Shiny.shinyapp.makeRequest()`. `Shiny.shinyapp.makeRequest()` makes a request
        to the server and waits for a response. By using `makeRequest()` (JS) and
        `set_message_handler()` (python), you can have a much richer communication
        interaction than just using Input values and re-rendering outputs.

        For example, `@render.data_frame` can have many cells edited. While it is
        possible to set many input values, if `makeRequest()` did not exist, the data
        frame would be updated on the first cell update. This would cause the data frame
        to be re-rendered, cancelling any pending cell updates. `makeRequest()` allows
        for individual cell updates to be sent to the server, processed, and handled by
        the existing data frame output.

        When the message handler is executed, it will be executed within an isolated
        reactive context and the session context that set the message handler.

        Parameters
        ----------
        name
            The name of the message handler.
        handler
            The handler function to be called when the client makes a message for the
            given name.  The handler function should take any number of arguments that
            are provided by the client and return a JSON-serializable object.

            If the value is `None`, then the handler at `name` will be removed.
        _handler_session
            For internal use. This is the session which will be used as the session
            context when calling the handler.

        Returns
        -------
        :
            The key under which the handler is stored (or removed). This value will be
            namespaced when used with a session proxy.
        """

    @abstractmethod
    def _increment_busy_count(self) -> None: ...

    @abstractmethod
    def _decrement_busy_count(self) -> None: ...

    def _otel_reactive_update_span(self) -> Optional[Span]:
        """The `reactive_update` span of this session's current cycle, if any."""
        return None

    def _restore_gate(self, priority: int) -> Optional[asyncio.Future[None]]:
        """
        The future that this session's effect with `priority` waits on before it runs,
        while the session restores its bookmarked state; `None` if it can run now.
        """
        return None

    def run_once_when_idle(self, fn: Callable[[], object]) -> None:
        """
        Run a function once, at the start of this session's next cycle.

        A session's cycle lasts until all of its effects have finished. Shiny holds
        input changes from the client and :func:`~shiny.reactive.invalidate_later`
        timers until then, so effects that are still running (e.g. paused at an
        ``await``) keep seeing the same values. Use this to change reactive state the
        same way, for example from a background task or a custom timer:

        ```python
        session.run_once_when_idle(lambda: latest.set(new_value))
        ```

        ``fn`` runs once this session is idle and its outputs have been sent; soon,
        but never synchronously, even if it is idle already. Functions queued while the
        session is busy run in order, each starting a cycle of its own, so the
        effects one of them triggers finish before the next runs. If the session
        ends first, ``fn`` doesn't run.

        Parameters
        ----------
        fn
            A synchronous function with no arguments; its return value is ignored.
            It runs with this session as the current session. An error it raises
            is printed with its traceback and closes the session, as an error in
            an effect does.

        Raises
        ------
        TypeError
            If ``fn`` is an async function. The function must run without
            yielding, so that it changes state all at once, before any effect it
            invalidates can run. For async work, start a task from ``fn`` with
            ``asyncio.create_task()``, or do it in an effect.
        """
        raise NotImplementedError(
            f"{type(self).__name__} does not implement `run_once_when_idle()`."
        )


def _print_exception(e: Exception) -> None:
    traceback.print_exception(type(e), e, e.__traceback__)


def _new_destroy_callbacks() -> _utils.AsyncCallbacks:
    return _utils.AsyncCallbacks(on_error=_print_exception)


def _ns_depth(ns_key: str) -> int:
    """
    Nesting depth of a namespace key, measured by its dash count.

    Used as a sort key so that deeper (more nested) namespaces sort first.
    """
    return ns_key.count("-")


async def _invoke_destroy_callbacks(
    callbacks_by_ns: dict[str, _utils.AsyncCallbacks],
    ns: str,
) -> None:
    """
    Invoke destroy callbacks for a namespace and all its descendants.

    Collects all namespaces matching ``ns`` (exact match) and any child
    namespaces (``ns + "-"`` prefix), sorts them deepest-first, then pops
    and invokes each set of callbacks.

    Parameters
    ----------
    callbacks_by_ns
        The dict mapping namespace strings to their ``AsyncCallbacks``.
    ns
        The namespace to destroy. Use ``""`` for the root session (destroys
        all namespaces).
    """
    if ns == "":
        # Root: destroy everything
        matching_keys = list(callbacks_by_ns.keys())
    else:
        ns_prefix = ns + "-"
        matching_keys = [
            k for k in callbacks_by_ns if k == ns or k.startswith(ns_prefix)
        ]

    # Sort deepest namespaces first (most dashes → most nested) so that
    # children are destroyed before parents, mirroring the reverse of
    # construction order.
    matching_keys.sort(key=_ns_depth, reverse=True)

    for ns_key in matching_keys:
        callbacks = callbacks_by_ns.pop(ns_key, None)
        if callbacks is not None:
            await callbacks.invoke()


def _validate_idle_action(fn: Callable[[], object]) -> None:
    """Reject an async `fn` for `run_once_when_idle()`, which calls it without awaiting."""
    if _utils.is_async_callable(fn):
        raise TypeError(
            "`session.run_once_when_idle()` takes a synchronous function. To do async "
            "work, start it from an effect, or from `fn` with `asyncio.create_task()`."
        )


def _validate_destroy_id(id: Id) -> None:
    """
    Validate the ``id`` passed to ``session.destroy(id)``.

    Must be a single, non-empty string. (When ``id`` is a plain ``str``, the
    permitted character set is additionally enforced by ``make_scope()`` via
    ``validate_id()``.)
    """
    if not isinstance(id, str) or id == "":
        raise ValueError(
            "`id` must be a single, non-empty string. Pass a module `id` to "
            'tear down that scope (e.g. `session.destroy("my_module")`), or '
            "call `destroy()` with no `id` to destroy the current scope."
        )


# ======================================================================================
# AppSession
# ======================================================================================


class AppSession(Session):
    """
    A class representing a user session.
    """

    # ==========================================================================
    # Initialization
    # ==========================================================================
    def __init__(
        self, app: App, id: str, conn: Connection, debug: bool = False
    ) -> None:
        self.ns: ResolvedId = Root
        self.app: App = app
        self.id: str = id
        self._conn: Connection = conn
        self._debug: bool = debug
        self._busy_count: int = 0
        # Spans this session's busy period (its cycle), as R does; see
        # `_increment_busy_count()`.
        self._otel_cycle_span: Optional[Span] = None
        # Whether an unhandled error closed the session during the current cycle.
        self._otel_cycle_failed: bool = False
        # The `session_start` span, while the server function and first cycle run.
        self._otel_session_start_span: Optional[Span] = None
        # Actions (input updates, timer invalidations) waiting for the session to be
        # idle.
        self._cycle_start_action_queue: list[Callable[[], None]] = []
        # Whether a cycle has finished since outputs were last sent. Every cycle ends
        # with a message, even an empty one. True so the first output flush always
        # sends.
        self._cycle_ended: bool = True
        # Whether output flush requests are honored: from init until the session loop
        # exits.
        self._output_flush_enabled: bool = False
        self._dispatch_tasks: set[asyncio.Task[None]] = set()
        # Whether this session's `on_flush` or `on_flushed` callbacks are running.
        self._running_output_callbacks: bool = False
        # Whether an output flush was requested while those callbacks ran (it repeats
        # the one running them).
        self._repeat_output_flush_requested: bool = False
        # The task sending this session's outputs, and whether to run it once more.
        self._output_flush_task: Optional[asyncio.Task[None]] = None
        self._output_flush_again: bool = False
        self._message_handlers: dict[
            str,
            tuple[Callable[..., Awaitable[Jsonifiable]], Session],
        ] = {}
        """
        Dictionary of message handlers for the session.

        If a request is sent from the client to the server via
        `window.Shiny.make_request()`, the server will look up the method in this
        dictionary and call the corresponding function with the arguments provided in
        the request.
        """
        self._init_message_handlers()

        # The HTTPConnection representing the WebSocket. This is used so that we can
        # query information about the request, like headers, cookies, etc.
        self.http_conn: HTTPConnection = conn.get_http_conn()

        self.input: Inputs = Inputs(dict())
        self.output: Outputs = Outputs(self, self.ns, outputs=dict())
        self.clientdata: ClientData = ClientData(self)

        self.bookmark: Bookmark = BookmarkApp(self)

        self._user: str | None = None
        self._groups: list[str] | None = None

        credentials_json: str = ""
        if "shiny-server-credentials" in self.http_conn.headers:
            credentials_json = self.http_conn.headers["shiny-server-credentials"]
        elif "rstudio-connect-credentials" in self.http_conn.headers:
            # Fall back to "rstudio-connect-credentials" if "shiny-server-credentials"
            # isn't available. Note: This is only needed temporarily, because Connect
            # treates PyShiny apps as FastAPI apps. When there's proper Shiny support,
            # this can be removed.
            credentials_json = self.http_conn.headers["rstudio-connect-credentials"]
        if credentials_json:
            try:
                creds = json.loads(credentials_json)
                self._user = creds["user"]
                self._groups = creds["groups"]
            except Exception as e:
                print("Error parsing credentials header: " + str(e), file=sys.stderr)

        self._outbound_message_queues = OutBoundMessageQueues(
            record_test_values=app._test_mode
        )

        self._file_upload_manager: FileUploadManager = FileUploadManager()
        self._on_ended_callbacks = _utils.AsyncCallbacks()
        self._has_run_session_ended_tasks: bool = False
        self._downloads: dict[str, DownloadInfo] = {}
        self._dynamic_routes: dict[str, DynamicRouteHandler] = {}

        # Test-mode (`SHINY_TESTMODE`) registry of values to include in the
        # `export` block of the snapshot. Keys are (namespaced) export names;
        # values are zero-arg callables evaluated lazily at snapshot time.
        self._test_value_exports: dict[str, Callable[[], Any]] = {}

        # Destroy callbacks for module scopes, keyed by namespace string.
        # Stored on root session because SessionProxy is a throwaway lens.
        self._destroy_callbacks_by_ns: dict[str, _utils.AsyncCallbacks] = {}

        self._register_session_ended_callbacks()

        self._flush_callbacks = _utils.AsyncCallbacks()
        self._flushed_callbacks = _utils.AsyncCallbacks()

    def _register_session_ended_callbacks(self) -> None:
        # This is to be called from the initialization. It registers functions
        # that are called when a session ends.

        # Clear file upload directories, if present
        self.on_ended(self._file_upload_manager.rm_upload_dir)

    def _is_closed(self) -> bool:
        # `_has_run_session_ended_tasks` is set before any teardown callback
        # runs, so teardown itself can tell a close from an explicit destroy().
        return self._has_run_session_ended_tasks

    async def _run_session_ended_tasks(self) -> None:
        if self._has_run_session_ended_tasks:
            return
        # Mark the session closed before running any teardown, so that the
        # destroy callbacks registered by reactive values and calcs can skip
        # tearing themselves down (see `_weak_destroy_callback`).
        self._has_run_session_ended_tasks = True

        # Wrap session cleanup in session_end span (or no-op if not collecting)
        with session_context(self):
            async with shiny_otel_span(
                "session_end",
                required_level=OtelCollectLevel.SESSION,
                collection_level=_get_env_level(),
                infer_session_id=True,
            ):
                try:
                    await self._on_ended_callbacks.invoke()
                    # Destroy callbacks run after on_ended callbacks so that
                    # on_ended handlers can still read reactive state.
                    await self.destroy()
                finally:
                    self._end_otel_cycle_span()
                    self.app._remove_session(self)

    def is_stub_session(self) -> Literal[False]:
        return False

    @property
    def user(self) -> str | None:
        return self._user

    @property
    def groups(self) -> list[str] | None:
        return self._groups

    async def close(self, code: int = 1001) -> None:
        await self._conn.close(code, None)
        await self._run_session_ended_tasks()

    async def _run(self) -> None:
        await self._run_impl()

    async def _run_impl(self) -> None:
        """Implementation of session execution loop."""
        conn_state: ConnectionState = ConnectionState.Start

        def verify_state(expected_state: ConnectionState) -> None:
            if conn_state != expected_state:
                raise ProtocolError("Invalid method for the current session state")

        with contextlib.ExitStack() as stack:
            try:
                await self._send_message(
                    {
                        "config": {
                            "workerId": "",
                            "sessionId": self.id,
                            "user": None,
                        }
                    }
                )

                while True:
                    message: str = await self._conn.receive()
                    if self._debug:
                        print("RECV: " + message, flush=True)

                    try:
                        message_obj = json.loads(
                            message, object_hook=_utils.lists_to_tuples
                        )
                    except json.JSONDecodeError:
                        warnings.warn(
                            "ERROR: Invalid JSON message", SessionWarning, stacklevel=2
                        )
                        return

                    if "method" not in message_obj:
                        self._print_error_message(
                            "Message does not contain 'method'.",
                        )
                        return

                    if message_obj["method"] == "init":
                        verify_state(ConnectionState.Start)

                        # BOOKMARKS!
                        if not isinstance(self.bookmark, BookmarkApp):
                            raise RuntimeError("`.bookmark` must be a BookmarkApp")

                        if ".clientdata_url_search" in message_obj["data"]:
                            self.bookmark._set_restore_context(
                                await RestoreContext.from_query_string(
                                    message_obj["data"][".clientdata_url_search"],
                                    app=self.app,
                                )
                            )
                        else:
                            self.bookmark._set_restore_context(RestoreContext())

                        # From now on, output flush requests send this session's
                        # outputs, errors, etc. to the client after the next round.
                        # When the session ends, stop.
                        self._output_flush_enabled = True
                        stack.callback(self._disable_output_flush)
                        stack.callback(self._cancel_dispatch_tasks)

                        conn_state = ConnectionState.Running
                        message_obj = typing.cast(ClientMessageInit, message_obj)
                        self._manage_inputs(message_obj["data"])

                        # Wrap server function initialization in session_start span
                        with session_context(self):
                            async with shiny_otel_span(
                                "session_start",
                                attributes=lambda: extract_http_attributes(
                                    self.http_conn
                                ),
                                required_level=OtelCollectLevel.SESSION,
                                collection_level=_get_env_level(),
                                infer_session_id=True,
                            ) as session_start_span:
                                self._otel_session_start_span = session_start_span
                                try:
                                    # The bookmark effects start the first cycle
                                    # (and its `reactive_update` span), so create
                                    # them once `session_start` is its parent.
                                    self.bookmark._create_effects()
                                    self.app.server(self.input, self.output, self)

                                    # Start the first cycle within the
                                    # `session_start` span. This doesn't wait for
                                    # async effects.
                                    self._request_output_flush()
                                    await _reactive_environment.start_round()
                                finally:
                                    self._otel_session_start_span = None

                    elif message_obj["method"] == "update":
                        verify_state(ConnectionState.Running)

                        data = typing.cast(ClientMessageUpdate, message_obj)["data"]

                        # Inputs change only between cycles, so effects that are
                        # still running keep seeing stable input values.
                        self.run_once_when_idle(
                            functools.partial(self._manage_inputs, data)
                        )

                    elif "tag" in message_obj and "args" in message_obj:
                        verify_state(ConnectionState.Running)

                        # Handlers can be slow; run them in their own task so the
                        # receive loop stays responsive. Responses carry the tag.
                        # `reactive.flush()` doesn't wait on these tasks.
                        task = asyncio.create_task(
                            self._dispatch(typing.cast(ClientMessageOther, message_obj))
                        )
                        self._dispatch_tasks.add(task)
                        task.add_done_callback(self._on_dispatch_done)

                    else:
                        raise ProtocolError(
                            f"Unrecognized method {message_obj['method']}"
                        )

                    self._request_output_flush()

            except ConnectionClosed:
                ...
            except Exception as e:
                try:
                    # Starting in Python 3.10 this could be traceback.print_exception(e)
                    traceback.print_exception(*sys.exc_info())
                    self._print_error_message(e)
                except Exception:
                    pass
                finally:
                    await self.close()
            finally:
                await self._run_session_ended_tasks()

    def _manage_inputs(self, data: dict[str, object]) -> None:
        for key, val in data.items():
            keys = key.split(":")
            if len(keys) > 2:
                raise ValueError(
                    "Input name+type is not allowed to contain more than one ':' -- "
                    + key
                )
            if len(keys) == 2:
                val = input_handlers._process_value(
                    keys[1], val, ResolvedId(keys[0]), self
                )

            # The keys[0] value is already a fully namespaced id; make that explicit by
            # wrapping it in ResolvedId, otherwise self.input will throw an id
            # validation error.
            # The client sends a value over the wire in two cases: either it's a
            # genuinely new value, or it was sent with {priority: "event"} which
            # bypasses client-side deduplication (InputNoResendDecorator). Either
            # way, the server should accept this value as new and cause dependents
            # to recalculate. This achieves dedupe=FALSE behavior from R Shiny:
            # https://github.com/rstudio/shiny/blob/75a63716e578976965daeadde81af7166a50faac/R/shiny.R#L728
            self.input[ResolvedId(keys[0])]._set(val, force=True)

        self.output._manage_hidden()

    def _is_hidden(self, name: str) -> bool:
        with isolate():
            # The .clientdata_output_{name}_hidden string is already a fully namespaced
            # id; make that explicit by wrapping it in ResolvedId, otherwise self.input
            # will throw an id validation error.
            hidden_value_obj = cast(
                Value[bool], self.input[ResolvedId(f".clientdata_output_{name}_hidden")]
            )
            if not hidden_value_obj.is_set():
                return True

            return hidden_value_obj()

    # ==========================================================================
    # Message handlers
    # ==========================================================================

    async def _dispatch(self, message: ClientMessageOther) -> None:
        try:
            async_func, handler_session = self._message_handlers[message["method"]]
        except KeyError:
            await self._send_error_response(
                message,
                "Unknown method: " + message["method"],
            )
            return
        except AttributeError:
            await self._send_error_response(
                message,
                "Unknown method: " + message["method"],
            )
            return

        try:
            # TODO: handle `blobs`

            # * Use the session context from when the message handler was set
            # * Using `isolate()` allows the handler to read reactive values in a
            #   non-reactive context
            with session_context(handler_session), isolate():
                value = await async_func(*message["args"])
        except Exception as e:
            # Safe error handling!
            if self.app.sanitize_errors and not isinstance(e, SafeException):
                await self._send_error_response(message, self.app.sanitize_error_msg)
            else:
                await self._send_error_response(message, str(e))
            return

        await self._send_response(message, value)

    async def _send_response(self, message: ClientMessageOther, value: object) -> None:
        await self._send_message({"response": {"tag": message["tag"], "value": value}})

    # This is called during __init__.
    def _init_message_handlers(self):
        # TODO-future; Make sure these methods work within MockSession

        async def uploadInit(file_infos: list[FileInfo]) -> dict[str, Jsonifiable]:
            with session_context(self):
                if self._debug:
                    print("Upload init: " + str(file_infos), flush=True)

                # TODO: Don't alter message in place?
                for fi in file_infos:
                    if fi["type"] == "":
                        fi["type"] = _utils.guess_mime_type(fi["name"])

                job_id = self._file_upload_manager.create_upload_operation(file_infos)
                worker_id = ""
                return {
                    "jobId": job_id,
                    "uploadUrl": f"session/{self.id}/upload/{job_id}?w={worker_id}",
                }

        async def uploadEnd(job_id: str, input_id: str) -> None:
            upload_op = self._file_upload_manager.get_upload_operation(job_id)
            if upload_op is None:
                warnings.warn(
                    "Received uploadEnd message for non-existent upload operation.",
                    SessionWarning,
                    stacklevel=2,
                )
                return None
            file_data = upload_op.finish()
            # Sets the input right away, even while this session's effects are still
            # running, unlike an `update` message, which waits for the cycle to end.
            # An effect that reads this input across an `await` can see it change.
            # Kept for parity with Shiny for R, whose `@uploadEnd` does the same.
            #
            # The input_id string is already a fully namespaced id; make that explicit
            # by wrapping it in ResolvedId, otherwise self.input will throw an id
            # validation error.
            self.input[ResolvedId(input_id)]._set(file_data)

            # This also occurs during input handler: shiny.file
            self.input.set_serializer(input_id, serializer_file_input)

            # Like R's @uploadEnd: scrub the nondeterministic tempdir out of the
            # value shown in test-mode snapshots.
            self.input.set_snapshot_preprocess(
                ResolvedId(input_id), _snapshot_preprocess_file_input
            )

            # Explicitly return None to signal that the message was handled.
            return None

        self.set_message_handler("uploadInit", uploadInit)
        self.set_message_handler("uploadEnd", uploadEnd)

    # ==========================================================================
    # Handling /session/{session_id}/{action}/{subpath} requests
    # ==========================================================================
    async def _handle_request(
        self, request: Request, action: str, subpath: Optional[str]
    ) -> ASGIApp:
        # Busy pauses this session's cycle (no input updates, timers, or outputs), so
        # only downloads take it, as in R; not uploads or dynamic routes. It covers
        # only the call to the download handler: a streamed body is read after this
        # returns, so values the stream sets reach the client while it streams, and
        # the session keeps handling input during a long download.
        busy = action == "download"
        if busy:
            self._increment_busy_count()
        try:
            return await self._handle_request_impl(request, action, subpath)
        finally:
            if busy:
                self._decrement_busy_count()

    async def _handle_request_impl(
        self, request: Request, action: str, subpath: Optional[str]
    ) -> ASGIApp:
        if action == "upload" and request.method == "POST":
            if subpath is None or subpath == "":
                return HTMLResponse("<h1>Bad Request</h1>", 400)

            job_id = subpath
            upload_op = self._file_upload_manager.get_upload_operation(job_id)
            if not upload_op:
                return HTMLResponse("<h1>Bad Request</h1>", 400)

            # The FileUploadOperation can have multiple files; each one will
            # have a separate POST request. Each call to  `with upload_op` will
            # open up each file (in sequence) for writing.
            with upload_op:
                async for chunk in request.stream():
                    upload_op.write_chunk(chunk)

            return PlainTextResponse("OK", 200)

        elif action == "download" and request.method == "GET" and subpath:
            download_id = subpath
            if download_id in self._downloads:
                with session_context(self):
                    with isolate():
                        download = self._downloads[download_id]
                        filename = read_thunk_opt(download.filename)
                        content_type = read_thunk_opt(download.content_type)
                        contents = download.handler()

                        if filename is None:
                            if isinstance(contents, str):
                                filename = os.path.basename(contents)
                            else:
                                warnings.warn(
                                    "Unable to infer a filename for the "
                                    f"'{download_id}' download handler; please use "
                                    "@render.download_button(filename=) to specify one "
                                    "manually",
                                    SessionWarning,
                                    stacklevel=2,
                                )
                                filename = download_id

                        if content_type is None:
                            content_type = _utils.guess_mime_type(filename)
                        content_disposition_filename = urllib.parse.quote(filename)
                        if content_disposition_filename != filename:
                            content_disposition = f"attachment; filename*=utf-8''{content_disposition_filename}"
                        else:
                            content_disposition = f'attachment; filename="{filename}"'
                        headers = {
                            "Content-Disposition": content_disposition,
                            "Cache-Control": "no-store",
                        }

                        # Parse namespace and base id from download_id
                        # IDs only contain \w characters, so "-" is exclusively
                        # the namespace separator (from ResolvedId)
                        if "-" in download_id:
                            dl_namespace, _, dl_base_id = download_id.rpartition("-")
                        else:
                            dl_namespace, dl_base_id = None, download_id

                        download_label = create_otel_label(
                            "download",
                            dl_base_id,
                            namespace=dl_namespace or None,
                        )

                        otel_attrs = {
                            **get_session_id_attrs(self),
                            "download.id": download_id,
                            "download.filename": filename,
                        }

                        if isinstance(contents, str):
                            # contents is the path to a file
                            # Span captures download initiation; the actual file
                            # transfer is handled by Starlette's ASGI layer after
                            # we return the FileResponse object.
                            async with shiny_otel_span(
                                download_label,
                                attributes=otel_attrs,
                                infer_session_id=False,
                                required_level=OtelCollectLevel.REACTIVITY,
                            ):
                                file_response = FileResponse(
                                    Path(contents),
                                    headers=headers,
                                    media_type=content_type,
                                )
                            return file_response

                        wrapped_contents: AsyncIterable[bytes]

                        if isinstance(contents, AsyncIterable):
                            # Need to wrap the app-author-provided iterator in a
                            # callback that installs the appropriate context mgrs.
                            # We already use this context mgrs further up in the
                            # implementation of handle_request(), but the iterators
                            # aren't invoked until after handle_request() returns.
                            async def wrap_content_async() -> AsyncIterable[bytes]:
                                with session_context(self):
                                    with isolate():
                                        async for chunk in contents:
                                            if isinstance(chunk, str):
                                                yield chunk.encode(download.encoding)
                                            else:
                                                yield chunk

                            wrapped_contents = wrap_content_async()

                        else:  # isinstance(contents, Iterable):

                            async def wrap_content_sync() -> AsyncIterable[bytes]:
                                with session_context(self):
                                    with isolate():
                                        for chunk in contents:
                                            if isinstance(chunk, str):
                                                yield chunk.encode(download.encoding)
                                            else:
                                                yield chunk

                            wrapped_contents = wrap_content_sync()

                        wrapped_contents = shiny_otel_span_stream(
                            download_label,
                            wrapped_contents,
                            attributes=otel_attrs,
                            infer_session_id=False,
                            required_level=OtelCollectLevel.REACTIVITY,
                        )

                        # In streaming downloads, we send a 200 response, but if an
                        # error occurs in the middle of it, the client needs to know.
                        # With chunked encoding, the client will know if an error occurs
                        # if it does not receive a terminating (empty) chunk.
                        headers["Transfer-Encoding"] = "chunked"

                        return StreamingResponse(
                            wrapped_contents,
                            200,
                            headers=headers,
                            media_type=content_type,  # type: ignore
                        )

        elif action == "dynamic_route" and request.method == "GET" and subpath:
            name = subpath
            handler = self._dynamic_routes.get(name, None)
            if handler is None:
                return HTMLResponse("<h1>Bad Request</h1>", 400)

            with session_context(self):
                with isolate():
                    if _utils.is_async_callable(handler):
                        return await handler(request)
                    else:
                        return handler(request)

        elif action == "dataobj" and subpath == "shinytest" and request.method == "GET":
            if not self.app._test_mode:
                return HTMLResponse("<h1>Not Found</h1>", 404)
            return await self._handle_test_snapshot(request)

        return HTMLResponse("<h1>Not Found</h1>", 404)

    async def _handle_test_snapshot(self, request: Request) -> ASGIApp:
        # `format`: py-shiny only ever emits JSON. R additionally supports "rds",
        # but there is no RDS equivalent in Python, so any non-"json" value
        # (including "rds") is rejected.
        fmt = request.query_params.get("format", "json")
        if fmt != "json":
            return PlainTextResponse(f"Invalid format requested: {fmt}", 400)

        # `sortC`: R uses this to choose radix (C-locale) vs locale-aware key
        # sorting. orjson always sorts keys by code point (equivalent to R's
        # radix) and has no locale-aware collation, so this is a no-op here -- but
        # it is validated the same way R does ("1" or not supplied).
        sort_c = request.query_params.get("sortC")
        if sort_c is not None and sort_c != "1":
            return PlainTextResponse(
                "The `sortC` parameter can only be `1` or not supplied.", 400
            )

        # Block selection. Each of `input`/`output`/`export` is included only if
        # its query param is present: "1" selects the whole block, a comma list
        # (e.g. "a,b") selects just those keys.
        #
        # DEVIATION FROM R: when NONE of the three params are supplied, py-shiny
        # returns all three blocks as a convenience. R instead responds 400
        # ("None of export, input, or output requested.").
        want = {block: request.query_params.get(block) for block in _SNAPSHOT_BLOCKS}
        payload = await self._build_test_snapshot(
            want_input=want["input"],
            want_output=want["output"],
            want_export=want["export"],
        )
        body = orjson.dumps(payload, option=orjson.OPT_SORT_KEYS)
        return Response(content=body, media_type="application/json")

    async def _build_test_snapshot(
        self,
        want_input: str | None = None,
        want_output: str | None = None,
        want_export: str | None = None,
    ) -> dict[str, dict[str, Any]]:
        select_all = want_input is None and want_output is None and want_export is None
        payload: dict[str, dict[str, Any]] = {}
        with session_context(self):
            with isolate():
                if select_all or want_input is not None:
                    inputs = {
                        str(key): _snapshot_safe_value(val)
                        for key, val in (
                            await self.input._serialize_test_mode()
                        ).items()
                    }
                    payload["input"] = _filter_snapshot_block(inputs, want_input)

                if select_all or want_output is not None:
                    omq = self._outbound_message_queues
                    outputs: dict[str, Any] = {}
                    for key, val in list(omq.test_values.items()):
                        info = self.output._outputs.get(key)
                        preprocess = (
                            info.renderer._snapshot_preprocess_fn
                            if info is not None
                            else None
                        )
                        if preprocess is not None:
                            try:
                                val = await preprocess(val)
                            except Exception as e:
                                val = {"__shiny_snapshot_preprocess_error__": str(e)}
                        outputs[str(key)] = _snapshot_safe_value(val)
                    for key, err in omq.test_errors.items():
                        if isinstance(err, dict):
                            message = cast("dict[str, Any]", err).get("message")
                        else:
                            message = str(err)
                        outputs[str(key)] = {"__shiny_output_error__": message}
                    payload["output"] = _filter_snapshot_block(outputs, want_output)

                if select_all or want_export is not None:
                    exports: dict[str, Any] = {}
                    for name, fn in self._test_value_exports.items():
                        try:
                            exports[name] = _snapshot_safe_value(fn())
                        except Exception as e:
                            exports[name] = {"__shiny_serialization_error__": str(e)}
                    payload["export"] = _filter_snapshot_block(exports, want_export)

        return payload

    def send_input_message(self, id: str, message: dict[str, object]) -> None:
        self._outbound_message_queues.add_input_message(id, message)
        self._request_output_flush()

    def _send_insert_ui(
        self, selector: str, multiple: bool, where: str, content: RenderedDeps
    ) -> None:
        msg = {
            "selector": selector,
            "multiple": multiple,
            "where": where,
            "content": content,
        }
        self._send_message_sync({"shiny-insert-ui": msg})

    def _send_remove_ui(self, selector: str, multiple: bool) -> None:
        msg = {"selector": selector, "multiple": multiple}
        self._send_message_sync({"shiny-remove-ui": msg})

    def _send_progress(self, type: str, message: object) -> None:
        msg: dict[str, object] = {"progress": {"type": type, "message": message}}
        self._send_message_sync(msg)

    async def send_custom_message(self, type: str, message: dict[str, object]) -> None:
        await self._send_message({"custom": {type: message}})

    async def _send_message(self, message: dict[str, object]) -> None:
        message_str = json.dumps(message)
        if self._debug:
            print(
                "SEND: "
                + re.sub(
                    "(?m)base64,[a-zA-Z0-9+/=]+", "[base64 data]", message_str + "\n"
                ),
                end="",
                flush=True,
            )
        await self._conn.send(message_str)

    def _send_message_sync(self, message: dict[str, object]) -> None:
        _utils.run_coro_hybrid(self._send_message(message))

    def _print_error_message(self, message: str | Exception) -> None:
        print(str(message), file=sys.stderr)

    async def _send_error_response(
        self,
        message: ClientMessageOther,
        error: object,
    ) -> None:
        # { tag: number; value?: ResponseValue; error?: string }
        if "tag" not in message:
            raise RuntimeError("No `tag` key in message")
        tag = message["tag"]
        await self._send_message({"response": {"tag": tag, "error": error}})

    # ==========================================================================
    # Flush
    # ==========================================================================
    def on_flush(
        self,
        fn: Callable[[], None] | Callable[[], Awaitable[None]],
        once: bool = True,
    ) -> Callable[[], None]:
        unregister = self._flush_callbacks.register(wrap_async(fn), once)
        self._request_output_flush()
        return unregister

    def on_flushed(
        self,
        fn: Callable[[], None] | Callable[[], Awaitable[None]],
        once: bool = True,
    ) -> Callable[[], None]:
        unregister = self._flushed_callbacks.register(wrap_async(fn), once)
        self._request_output_flush()
        return unregister

    def _request_output_flush(self) -> None:
        """Send this session's outputs after the next round."""
        if not self._output_flush_enabled:
            return
        if self._running_output_callbacks:
            # E.g. a `ui.update_*()` in an `on_flushed` callback, or a callback
            # registered too late for the ones being run. It's one more output flush,
            # after this one. Paced, since a callback that requests one each time it
            # runs would otherwise keep the session flushing as fast as it can.
            self._repeat_output_flush_requested = True
        self.app._request_output_flush(self)

    def _cancel_dispatch_tasks(self) -> None:
        for task in list(self._dispatch_tasks):
            task.cancel()

    def _on_dispatch_done(self, task: asyncio.Task[None]) -> None:
        self._dispatch_tasks.discard(task)
        if task.cancelled():
            return
        e = task.exception()
        if isinstance(e, Exception):
            # E.g. the response couldn't be sent. This closes the session, as an
            # error in the receive loop does.
            traceback.print_exception(type(e), e, e.__traceback__)
            _reactive_environment._spawn(self._unhandled_error(e))

    def _disable_output_flush(self) -> None:
        self._output_flush_enabled = False
        self.app._sessions_needing_output_flush.pop(self.id, None)

    def _start_output_flush(self) -> None:
        """
        Send this session's outputs in a task of its own.

        At most one runs per session: if an output flush is requested while one is
        still sending, it runs once more when that one finishes, so messages stay in
        order. An error closes this session only. `reactive.flush()` waits for these
        tasks, so after it returns the messages have been sent.
        """
        if self._output_flush_task is not None and not self._output_flush_task.done():
            self._output_flush_again = True
            return
        self._output_flush_task = _reactive_environment._spawn(self._run_output_flush())

    async def _run_output_flush(self) -> None:
        # `reactive.flush()` from this session's flush callbacks (or tasks they
        # start) returns right away rather than waiting on this task.
        _enclosing_run.set(asyncio.current_task())
        while self._output_flush_enabled:
            self._output_flush_again = False
            if self._repeat_output_flush_requested:
                self._repeat_output_flush_requested = False
                await asyncio.sleep(REPEAT_OUTPUT_FLUSH_DELAY_SECS)
                if not self._output_flush_enabled:
                    return
            try:
                await self._output_flush()
            except Exception as e:
                # Show where it failed (an input update, a flush callback, ...);
                # `_unhandled_error()` prints only the message.
                _print_exception(e)
                await self._unhandled_error(e)
            if not self._output_flush_again:
                return

    async def _output_flush(self) -> None:
        # Outputs go out once per cycle: while any of this session's effects are
        # still running, hold everything. The idle transition requests an output flush.
        if self._busy_count > 0:
            return
        if (
            self._cycle_start_action_queue
            and not self._cycle_ended
            and self._outbound_message_queues.is_empty()
        ):
            # Nothing to report before the queued action (e.g. an input update) runs.
            self._start_cycle()
            return

        with session_context(self):
            # This is the only place in the session where the RestoreContext is flushed.
            if self.bookmark._restore_context:
                self.bookmark._restore_context.flush_pending()
            await self._invoke_output_callbacks(self._flush_callbacks)

        # Async flush callbacks yield, and an effect may have started meanwhile; its
        # cycle's idle transition sends everything still queued.
        if self._busy_count > 0:
            return

        try:
            await self._send_queued_outputs()
        finally:
            with session_context(self):
                await self._invoke_output_callbacks(self._flushed_callbacks)

        # This cycle's outputs are out; start the next one.
        self._start_cycle()

    async def _invoke_output_callbacks(self, callbacks: _utils.AsyncCallbacks) -> None:
        self._running_output_callbacks = True
        try:
            await callbacks.invoke()
        finally:
            self._running_output_callbacks = False

    async def _send_queued_outputs(self) -> None:
        omq = self._outbound_message_queues
        # Send only when a cycle has ended or something is queued (R's
        # `hasPendingUpdates()`). A cycle's message is sent even when empty: the
        # client uses it to settle outputs still showing progress (e.g. after
        # `req(False, cancel_output=True)`).
        if self._cycle_ended or not omq.is_empty():
            # Take the queued values before awaiting the send, so a value
            # written during the send stays queued for the next message.
            message: dict[str, object] = {
                "values": dict(omq.values),
                "inputMessages": list(omq.input_messages),
                "errors": dict(omq.errors),
            }
            omq.reset()
            self._cycle_ended = False
            await self._send_message(message)

    def _increment_busy_count(self) -> None:
        self._busy_count += 1
        if self._busy_count == 1:
            self._send_message_sync({"busy": "busy"})
            # A flush is global and can serve several sessions, so the
            # `reactive_update` span follows this session's cycle instead: it starts
            # now and ends when all of the session's effects have finished. A
            # download marks the session busy too (see `_handle_request()`), so it
            # gets a span of its own, as in R.
            if self._otel_cycle_span is None:
                # Choose the parent explicitly. This runs in whichever task
                # invalidated the effect, often another session's effect or an
                # earlier cycle of this one, and that task's span isn't this
                # cycle's parent. The first cycle belongs to `session_start`;
                # later ones each start a trace of their own.
                if self._otel_session_start_span is not None:
                    parent = set_span_in_context(self._otel_session_start_span)
                else:
                    parent = OtelContext()
                self._otel_cycle_failed = False
                self._otel_cycle_span = start_otel_span(
                    "reactive_update",
                    attributes=get_session_id_attrs(self),
                    required_level=OtelCollectLevel.REACTIVE_UPDATE,
                    collection_level=_get_env_level(),
                    context=parent,
                )

    def _decrement_busy_count(self) -> None:
        self._busy_count -= 1
        if self._busy_count == 0:
            self._end_otel_cycle_span()
            self._send_message_sync({"busy": "idle"})
            # `_output_flush` sends this cycle's outputs, then starts the next action.
            self._cycle_ended = True
            self._request_output_flush()

    def _otel_reactive_update_span(self) -> Optional[Span]:
        return self._otel_cycle_span

    def _restore_gate(self, priority: int) -> Optional[asyncio.Future[None]]:
        if isinstance(self.bookmark, BookmarkApp):
            return self.bookmark._restore_gate(priority)
        return None

    def _end_otel_cycle_span(self) -> None:
        span, self._otel_cycle_span = self._otel_cycle_span, None
        if span is not None:
            if not self._otel_cycle_failed:
                span.set_status(Status(StatusCode.OK))
            span.end()

    def run_once_when_idle(self, fn: Callable[[], object]) -> None:
        # Actions are sync, so they can't be interrupted partway, and only
        # `_output_flush` runs them (never whichever task happened to queue one).
        _validate_idle_action(fn)
        # Nothing drains the queue once the session has ended, so a timer that
        # keeps calling this would grow it forever.
        if self._has_run_session_ended_tasks:
            return

        def action() -> None:
            with session_context(self):
                fn()

        self._cycle_start_action_queue.append(action)
        self._request_output_flush()

    def _start_cycle(self) -> None:
        # One action per cycle; the next runs after the outputs this one causes.
        if self._busy_count != 0 or not self._cycle_start_action_queue:
            return
        if self._has_run_session_ended_tasks:
            self._cycle_start_action_queue.clear()
            return
        action = self._cycle_start_action_queue.pop(0)
        try:
            action()
        finally:
            # The cycle this action starts ends when its effects finish (the idle
            # transition), or right away if it started none.
            self._cycle_ended = True
            self._request_output_flush()

    # ==========================================================================
    # On session ended
    # ==========================================================================
    def on_ended(
        self,
        fn: Callable[[], None] | Callable[[], Awaitable[None]],
    ) -> Callable[[], None]:
        return self._on_ended_callbacks.register(wrap_async(fn))

    def on_destroy(
        self, fn: Callable[[], None] | Callable[[], Awaitable[None]]
    ) -> None:
        self._register_destroy(fn, ns="", first=False)

    def _register_destroy(
        self,
        fn: Callable[[], None] | Callable[[], Awaitable[None]],
        *,
        ns: str,
        first: bool,
    ) -> None:
        """
        Register ``fn`` to run when the scope ``ns`` is destroyed (``""`` for this
        root scope, ``str(proxy.ns)`` for a module scope).

        With ``first=True``, ``fn`` runs before the callbacks registered with
        ``first=False`` on that scope, however they interleave. (Child scopes are
        destroyed before their parent, so a parent scope's effect is cancelled only
        after its children's values are gone.) Effects use this so that their
        in-progress runs are cancelled before an async destroy callback can yield
        to them while the scope's values are already gone.
        """
        if ns not in self._destroy_callbacks_by_ns:
            self._destroy_callbacks_by_ns[ns] = _new_destroy_callbacks()
        self._destroy_callbacks_by_ns[ns].register(wrap_async(fn), first=first)

    async def destroy(self, id: Id | None = None) -> None:
        if id is None:
            await _invoke_destroy_callbacks(self._destroy_callbacks_by_ns, "")
        else:
            _validate_destroy_id(id)
            await self.make_scope(id).destroy()

    # ==========================================================================
    # Misc
    # ==========================================================================
    async def _unhandled_error(self, e: Exception) -> None:
        print("Unhandled error: " + str(e), file=sys.stderr)
        # The effect's own span has already reported OK (it handled the error), so
        # the cycle's span is what shows that this error closed the session.
        if self._otel_cycle_span is not None:
            self._otel_cycle_failed = True
            self._otel_cycle_span.record_exception(e)
            self._otel_cycle_span.set_status(Status(StatusCode.ERROR, str(e)))
        await self.close()

    def download(
        self,
        id: Optional[str] = None,
        filename: Optional[str | Callable[[], str]] = None,
        media_type: None | str | Callable[[], str] = None,
        encoding: str = "utf-8",
    ) -> Callable[[DownloadHandler], None]:
        warn_deprecated(
            "session.download() is deprecated. Please use render.download_button() instead."
        )

        def wrapper(fn: DownloadHandler):
            effective_name = id or fn.__name__

            self._downloads[effective_name] = DownloadInfo(
                filename=filename,
                content_type=media_type,
                handler=fn,
                encoding=encoding,
            )

            @self.output(id=effective_name)
            @render.text
            @functools.wraps(fn)
            def _():
                # TODO: the `w=` parameter should eventually be a worker ID, if we add those
                return f"session/{urllib.parse.quote(self.id)}/download/{urllib.parse.quote(effective_name)}?w="

        return wrapper

    def dynamic_route(self, name: str, handler: DynamicRouteHandler) -> str:

        self._dynamic_routes.update({name: handler})
        nonce = _utils.rand_hex(8)
        return f"session/{urllib.parse.quote(self.id)}/dynamic_route/{urllib.parse.quote(name)}?nonce={urllib.parse.quote(nonce)}"

    def _export_test_values(self, **kwargs: Callable[[], Any]) -> None:
        if not self.app._test_mode:
            return
        self._test_value_exports.update(kwargs)

    def get_test_snapshot_url(self) -> str:
        nonce = _utils.rand_hex(8)
        return (
            f"session/{urllib.parse.quote(self.id)}"
            f"/dataobj/shinytest?nonce={urllib.parse.quote(nonce)}"
        )

    def set_message_handler(
        self,
        name: str,
        handler: (
            Callable[..., Jsonifiable] | Callable[..., Awaitable[Jsonifiable]] | None
        ),
        *,
        _handler_session: Optional[Session] = None,
    ) -> str:
        # Verify that the name is a string
        assert isinstance(name, str)

        if _handler_session is None:
            _handler_session = self

        if handler is None:
            if name in self._message_handlers:
                del self._message_handlers[name]
        else:
            assert callable(handler)
            self._message_handlers[name] = (wrap_async(handler), _handler_session)
        return name

    def _process_ui(self, ui: TagChild) -> RenderedDeps:
        res = TagList(ui).render()
        deps: list[dict[str, Any]] = []
        for dep in res["dependencies"]:
            self.app._register_web_dependency(dep)
            dep_dict = dep.as_dict(lib_prefix=self.app.lib_prefix)
            deps.append(dep_dict)

        return {"deps": deps, "html": res["html"]}

    def make_scope(self, id: Id) -> Session:
        ns = self.ns(id)
        return SessionProxy(root_session=self, ns=ns)

    def root_scope(self) -> AppSession:
        return self


class BindingProgressMessage(TypedDict):
    id: ResolvedId
    persistent: NotRequired[bool]


class OpenProgressMessage(TypedDict):
    id: ResolvedId
    style: str


class CloseProgressMessage(TypedDict):
    id: ResolvedId
    style: str


class UpdateProgressMessage(TypedDict):
    id: ResolvedId
    message: NotRequired[str | None]
    detail: NotRequired[str | None]
    value: NotRequired[float | int | None]
    style: str


# ======================================================================================
# SessionProxy
# ======================================================================================


class SessionProxy(Session):
    def __init__(self, root_session: Session, ns: ResolvedId) -> None:
        super().__init__()

        self._root_session = root_session
        self.app = root_session.app
        self.id = root_session.id
        self.ns = ns
        self.input = Inputs(values=root_session.input._map, ns=ns)
        # Share snapshot-preprocessor storage with the root session so that
        # registrations made inside modules are visible to the (root) snapshot
        # handler, like the shared `_map`.
        self.input._snapshot_preprocessors = root_session.input._snapshot_preprocessors
        self.output = Outputs(
            self,
            ns=ns,
            outputs=root_session.output._outputs,
        )
        self.clientdata = ClientData(self)
        self._outbound_message_queues = root_session._outbound_message_queues
        self._downloads = root_session._downloads

        self.bookmark = BookmarkProxy(self)

    @property
    def user(self) -> str | None:
        return self._root_session.user

    @property
    def groups(self) -> list[str] | None:
        return self._root_session.groups

    def _is_closed(self) -> bool:
        return self._root_session._is_closed()

    def on_destroy(
        self, fn: Callable[[], None] | Callable[[], Awaitable[None]]
    ) -> None:
        """
        Register a callback to run when this module scope is destroyed.

        Destroy callbacks fire when ``destroy()`` is explicitly called, or
        automatically at session end (after ``on_ended`` callbacks). Note that
        the session-end path leaves the scope's reactive values and calcs
        readable; only an explicit ``destroy()`` tears them down. See
        :meth:`~shiny.Session.destroy`.

        Parameters
        ----------
        fn
            The function to call when destroy occurs.
        """
        destroy_cbs: dict[str, _utils.AsyncCallbacks] | None = getattr(
            self._root_session, "_destroy_callbacks_by_ns", None
        )
        if destroy_cbs is not None:
            ns_key = str(self.ns)
            if ns_key not in destroy_cbs:
                destroy_cbs[ns_key] = _new_destroy_callbacks()
            destroy_cbs[ns_key].register(wrap_async(fn))

    async def destroy(self, id: Id | None = None) -> None:
        # When `id` is given, destroy that child scope rather than this scope.
        if id is not None:
            _validate_destroy_id(id)
            await self.make_scope(id).destroy()
            return

        destroy_cbs: dict[str, _utils.AsyncCallbacks] | None = getattr(
            self._root_session, "_destroy_callbacks_by_ns", None
        )
        if destroy_cbs is not None:
            await _invoke_destroy_callbacks(destroy_cbs, str(self.ns))

        # Destroy inputs and outputs after callbacks, so that callback
        # functions can still read input/output values during destruction.
        # Remove namespaced input keys and their values.
        self.input._destroy()
        # Remove namespaced output entries and destroy their effects.
        self.output._destroy()

        # Clean up namespaced registrations that the module made on the root
        # session. These dicts use namespaced keys (via self.ns(name)), so
        # entries from a destroyed module would otherwise persist for the
        # session lifetime — leaking handler closures and preventing GC of
        # objects they capture.
        ns_str = str(self.ns)
        ns_prefix = ns_str + "-"
        for attr in ("_message_handlers", "_dynamic_routes", "_downloads"):
            registry: dict[str, object] | None = getattr(self._root_session, attr, None)
            if registry is None:
                continue
            keys_to_remove = [
                k for k in registry if k == ns_str or k.startswith(ns_prefix)
            ]
            for k in keys_to_remove:
                del registry[k]

    def _is_hidden(self, name: str) -> bool:
        return self._root_session._is_hidden(name)

    def on_ended(
        self,
        fn: Callable[[], None] | Callable[[], Awaitable[None]],
    ) -> Callable[[], None]:
        return self._root_session.on_ended(fn)

    def is_stub_session(self) -> bool:
        return self._root_session.is_stub_session()

    async def close(self, code: int = 1001) -> None:
        await self._root_session.close(code)

    def make_scope(self, id: str) -> Session:
        return self._root_session.make_scope(self.ns(id))

    def root_scope(self) -> Session:
        return self._root_session

    def _process_ui(self, ui: TagChild) -> RenderedDeps:
        return self._root_session._process_ui(ui)

    def send_input_message(self, id: str, message: dict[str, object]) -> None:
        self._root_session.send_input_message(self.ns(id), message)

    def _send_insert_ui(
        self, selector: str, multiple: bool, where: str, content: RenderedDeps
    ) -> None:
        self._root_session._send_insert_ui(selector, multiple, where, content)

    def _send_remove_ui(self, selector: str, multiple: bool) -> None:
        self._root_session._send_remove_ui(selector, multiple)

    def _send_progress(self, type: str, message: object) -> None:
        self._root_session._send_progress(type, message)  # pyright: ignore

    async def send_custom_message(self, type: str, message: dict[str, object]) -> None:
        await self._root_session.send_custom_message(type, message)

    def _increment_busy_count(self) -> None:
        self._root_session._increment_busy_count()

    def _decrement_busy_count(self) -> None:
        self._root_session._decrement_busy_count()

    def _otel_reactive_update_span(self) -> Optional[Span]:
        return self._root_session._otel_reactive_update_span()

    def _restore_gate(self, priority: int) -> Optional[asyncio.Future[None]]:
        return self._root_session._restore_gate(priority)

    def run_once_when_idle(self, fn: Callable[[], object]) -> None:
        _validate_idle_action(fn)

        def action() -> None:
            with session_context(self):
                fn()

        self._root_session.run_once_when_idle(action)

    def set_message_handler(
        self,
        name: str,
        handler: (
            Callable[..., Jsonifiable] | Callable[..., Awaitable[Jsonifiable]] | None
        ),
        *,
        _handler_session: Optional[Session] = None,
    ) -> str:
        # Verify that the name is a string
        assert isinstance(name, str)

        if _handler_session is None:
            _handler_session = self

        return self._root_session.set_message_handler(
            self.ns(name),
            handler,
            _handler_session=_handler_session,
        )

    def on_flush(
        self,
        fn: Callable[[], None] | Callable[[], Awaitable[None]],
        once: bool = True,
    ) -> Callable[[], None]:
        return self._root_session.on_flush(fn, once)

    async def _send_message(self, message: dict[str, object]) -> None:
        await self._root_session._send_message(message)

    def _send_message_sync(self, message: dict[str, object]) -> None:
        self._root_session._send_message_sync(message)

    def on_flushed(
        self,
        fn: Callable[[], None] | Callable[[], Awaitable[None]],
        once: bool = True,
    ) -> Callable[[], None]:
        return self._root_session.on_flushed(fn, once)

    def dynamic_route(self, name: str, handler: DynamicRouteHandler) -> str:
        return self._root_session.dynamic_route(self.ns(name), handler)

    def _export_test_values(self, **kwargs: Callable[[], Any]) -> None:
        # NOTE: Deviation from R Shiny's `exportTestValues()`, which does NOT
        # namespace export names. py-shiny namespaces them with this module's
        # `ns` prefix so values exported from different modules don't collide.
        namespaced = {str(self.ns(name)): value for name, value in kwargs.items()}
        self._root_session._export_test_values(**namespaced)

    def get_test_snapshot_url(self) -> str:
        return self._root_session.get_test_snapshot_url()

    async def _unhandled_error(self, e: Exception) -> None:
        await self._root_session._unhandled_error(e)

    def download(
        self,
        id: Optional[str] = None,
        filename: Optional[str | Callable[[], str]] = None,
        media_type: None | str | Callable[[], str] = None,
        encoding: str = "utf-8",
    ) -> Callable[[DownloadHandler], None]:
        def wrapper(fn: DownloadHandler):
            id_ = self.ns(id or fn.__name__)
            return self._root_session.download(
                id=id_,
                filename=filename,
                media_type=media_type,
                encoding=encoding,
            )(fn)

        return wrapper


# ======================================================================================
# Inputs
# ======================================================================================


_SNAPSHOT_BLOCKS = ("input", "output", "export")
"""The block names selectable via the test-snapshot endpoint's query params."""


def _snapshot_safe_value(value: Any) -> Any:
    """
    Coerce a value into something JSON-serializable for a test snapshot.

    Best-effort: values that orjson cannot encode are stringified via
    `default=str`. If serialization still fails (e.g. `str()` raises), a visible,
    non-fatal marker is returned so a single bad value never fails the whole
    snapshot.
    """
    try:
        return orjson.loads(orjson.dumps(value, default=str))
    except Exception as e:
        return {"__shiny_serialization_error__": str(e)}


def _filter_snapshot_block(block: dict[str, Any], spec: str | None) -> dict[str, Any]:
    """
    Select keys from a test-snapshot block per a query-param value.

    `spec` of `None` (the select-all default) or `"1"` returns the whole block; a
    comma-separated list returns only those keys that exist in the block (unknown
    names are silently dropped, matching R).
    """
    if spec is None or spec == "1":
        return block
    return {name: block[name] for name in spec.split(",") if name in block}


def _is_internal_snapshot_input(key: str) -> bool:
    """
    Whether an input key is client-internal and excluded from snapshots.

    Used by both bookmark serialization and test-mode snapshots to skip
    client-data inputs (`.clientdata_*`) and the bookmark machinery inputs.
    """
    if key.startswith(".clientdata_"):
        return True
    if key == BOOKMARK_ID or key.endswith(f"{ResolvedId._sep}{BOOKMARK_ID}"):
        return True
    return False


# TODO: provide a real input typing example when we have an answer for that
# https://github.com/posit-dev/py-shiny/issues/70
class Inputs:
    """
    A class representing Shiny input values.

    This class provides access to a :class:`~shiny.Session`'s input values. The
    input values are reactive :class:`~shiny.reactive.Value`s, and can be accessed with
    the ``[]`` operator, or with ``.``. For example, if there is an input named ``x``,
    it can be accessed via `input["x"]()` or ``input.x()``.
    """

    _serializers: dict[
        str,
        Callable[
            [Any, Path | None],
            Awaitable[Any | Unserializable],
        ],
    ]
    """
    A dictionary of serializers for input values.

    Set this value via `Inputs.set_serializer(id, fn)`.
    """

    _snapshot_preprocessors: dict[str, Callable[[Any], Awaitable[Any]]]
    """
    Preprocessors applied to input values in test-mode snapshots.

    Keyed by resolved input id; values are async-wrapped callables. Set via
    `Inputs.set_snapshot_preprocess(id, fn)`.
    """

    def __init__(
        self, values: dict[str, Value[Any]], ns: Callable[[str], ResolvedId] = Root
    ) -> None:
        self._map = values
        self._ns = ns
        self._serializers = {}
        self._snapshot_preprocessors = {}

    def __setitem__(self, key: str, value: Value[Any]) -> None:
        if not isinstance(value, reactive.Value):
            raise TypeError("`value` must be a reactive.Value object.")

        # Set the name on the Value for OpenTelemetry logging (before namespacing)
        # The module ns will be included separately
        # Keys starting with "." (like .clientdata_*) use the full key as the name
        if key.startswith("."):
            value._name = key
        else:
            value._name = f"input.{key}"
        self._map[self._ns(key)] = value

    def __getitem__(self, key: str) -> Value[Any]:
        original_key = key
        key = self._ns(key)
        # Auto-populate key if accessed but not yet set. Needed to take reactive
        # dependencies on input values that haven't been received from client
        # yet.
        if key not in self._map:
            # Set the name for OpenTelemetry logging (before namespacing)
            # The module ns will be included separately
            # Exclude things like `.clientData`
            value_name = (
                original_key
                if original_key.startswith(".")
                else f"input.{original_key}"
            )

            new_value = Value[Any](read_only=True, name=value_name)

            # Do not call __setitem__ directly here. The _name would be undone
            self._map[key] = new_value

        return self._map[key]

    def __delitem__(self, key: str) -> None:
        del self._map[self._ns(key)]

    # Allow access of values as attributes.
    def __setattr__(self, attr: str, value: Value[Any]) -> None:
        if attr in ("_map", "_ns", "_serializers", "_snapshot_preprocessors"):
            super().__setattr__(attr, value)
            return

        self.__setitem__(attr, value)

    def __getattr__(self, attr: str) -> Value[Any]:
        if attr in ("_map", "_ns", "_serializers", "_snapshot_preprocessors"):
            return object.__getattribute__(self, attr)
        return self.__getitem__(attr)

    def __delattr__(self, key: str) -> None:
        self.__delitem__(key)

    def __contains__(self, key: str) -> bool:
        # This looks simple, but does a number of things. By accessing `self[key]`, it
        # indirectly calls `__getitem__`, which applies a namespace to the key, and
        # it populates the key if it doesn't exist yet. It then calls `is_set()`, which
        # creates a reactive dependency, and returns whether the value is set.
        return self[key].is_set()

    def __dir__(self):
        return list(self._map.keys())

    # This method can not be on the `Value` class as the _value_ may not exist when the
    # "creating" method is executed.
    # Ex: File inputs do not _make_ the input reactive value. The browser does when the
    # client sets the value.
    def set_serializer(
        self,
        id: str,
        fn: (
            Callable[
                [Any, Path | None],
                Awaitable[Any | Unserializable],
            ]
            | Callable[
                [Any, Path | None],
                Any | Unserializable,
            ]
        ),
    ) -> None:
        """
        Add a function for serializing an input before bookmarking application state

        Parameters
        ----------
        id
            The ID of the input value.
        fn
            A function that takes the input value and returns a modified value. The
            returned value will be used for bookmarking.
        """
        self._serializers[id] = wrap_async(fn)

    def set_snapshot_preprocess(
        self,
        id: str,
        fn: Callable[[Any], Any] | Callable[[Any], Awaitable[Any]],
    ) -> None:
        """
        Set a function for preprocessing an input value in test-mode snapshots.

        When a test snapshot is requested (see `shiny.testmode`), the registered
        function receives the input's current value and its return value is
        written to the snapshot instead. Use this to scrub non-deterministic
        values (timestamps, temp paths, random ids) so snapshots diff cleanly.

        The function may be synchronous or asynchronous. It only affects test
        snapshots -- never the live input value. Registering again for the same
        `id` overwrites the previous function. Registration is harmless when
        test mode is off, so calls can be left in production code.

        Parameters
        ----------
        id
            The ID of the input value.
        fn
            A function that takes the input value and returns the value to
            write to the test snapshot.

        See Also
        --------
        * :func:`~shiny.testmode.snapshot_preprocess_input`
        * :meth:`~shiny.render.renderer.Renderer.snapshot_preprocess`
        * :func:`~shiny.testmode.export_test_values`
        * :class:`~shiny.playwright.controller.AppTestValues`
        """
        self._snapshot_preprocessors[self._ns(id)] = wrap_async(fn)

    async def _serialize(
        self,
        /,
        *,
        exclude: list[str],
        state_dir: Path | None,
    ) -> dict[str, Any]:
        from ..bookmark._serializers import Unserializable, serializer_default

        exclude_set = set(exclude)
        serialized_values: dict[str, Any] = {}

        with reactive.isolate():

            for key, value in self._map.items():
                if _is_internal_snapshot_input(str(key)):
                    continue
                if key in exclude_set:
                    continue

                try:
                    val = value()
                except SilentException:
                    continue

                # Possibly apply custom serialization given the input id
                serializer = self._serializers.get(key, serializer_default)
                serialized_value = await serializer(val, state_dir)

                # Filter out any values that were marked as unserializable.
                if isinstance(serialized_value, Unserializable):
                    continue
                serialized_values[str(key)] = serialized_value

        return serialized_values

    async def _serialize_test_mode(self) -> dict[str, Any]:
        """
        Collect current input values for a test-mode snapshot.

        Unlike `_serialize` (used for bookmarking), this applies no bookmark
        serializers and never touches the filesystem; raw values are returned for
        best-effort JSON serialization by the snapshot handler. Client-internal
        and bookmark inputs are skipped. Snapshot preprocessors (see
        `set_snapshot_preprocess`) are applied; a raising preprocessor becomes a
        visible, non-fatal `__shiny_snapshot_preprocess_error__` marker.
        """
        out: dict[str, Any] = {}
        with reactive.isolate():
            # Materialize the items: an async preprocessor may yield to the
            # event loop mid-iteration, during which the client can add new
            # inputs to `_map`.
            for key, value in list(self._map.items()):
                if _is_internal_snapshot_input(str(key)):
                    continue
                try:
                    val = value()
                except SilentException:
                    continue
                preprocess = self._snapshot_preprocessors.get(key)
                if preprocess is not None:
                    try:
                        val = await preprocess(val)
                    except Exception as e:
                        val = {"__shiny_snapshot_preprocess_error__": str(e)}
                out[str(key)] = val
        return out

    def _destroy(self) -> None:
        # This will cause all modules with the same module namespace prefix to have their inputs removed.
        # So if one parent module is being torn down, all descendant modules will be torn down.
        # Just like with Outputs

        prefix = str(self._ns) + "-"
        clientdata_prefix = f".clientdata_output_{self._ns}-"
        keys_to_remove = [
            k
            for k in self._map
            if k.startswith(prefix) or k.startswith(clientdata_prefix)
        ]
        for key in keys_to_remove:
            value_obj = self._map[key]
            value_obj.destroy()
            del self._map[key]


# The output whose renderer is running in the current task, for
# `session.clientdata.output_*()` called with no id. A ContextVar, because a session's
# async outputs run as concurrent tasks that interleave at each `await`, and each one
# must see only its own name.
_current_output_name: ContextVar[ResolvedId | None] = ContextVar(
    "shiny_current_output_name", default=None
)


@add_example()
class ClientData:
    """
    Access (client-side) information from the browser.

    Provides access to client-side information, such as the URL components, the
    pixel ratio of the device, and the properties of outputs.

    Each method in this class reads a reactive input value, which means that the
    method will error if called outside of a reactive context.

    Raises
    ------
    RuntimeError
        If a method is called outside of a reactive context.
    """

    def __init__(self, session: Session) -> None:
        self._session: Session = session

    def url_hash(self) -> str:
        """
        Reactively read the hash part of the URL.
        """
        return self._read_input("url_hash")

    def url_hash_initial(self) -> str:
        """
        Reactively read the initial hash part of the URL.
        """
        return self._read_input("url_hash_initial")

    def url_hostname(self) -> str:
        """
        Reactively read the hostname part of the URL.
        """
        return self._read_input("url_hostname")

    def url_pathname(self) -> str:
        """
        The pathname part of the URL.
        """
        return self._read_input("url_pathname")

    def url_port(self) -> int:
        """
        Reactively read the port part of the URL.
        """
        return cast(int, self._read_input("url_port"))

    def url_protocol(self) -> str:
        """
        Reactively read the protocol part of the URL.
        """
        return self._read_input("url_protocol")

    def url_search(self) -> str:
        """
        Reactively read the search part of the URL.
        """
        return self._read_input("url_search")

    def pixelratio(self) -> float:
        """
        Reactively read the pixel ratio of the device.
        """
        return cast(int, self._read_input("pixelratio"))

    def output_height(self, id: Optional[Id] = None) -> float | None:
        """
        Reactively read the height of an output.

        Parameters
        ----------
        id
            The id of the output.

        Returns
        -------
        float | None
            The height of the output, or None if the output does not exist (or does not
            report its height).
        """
        return cast(float, self._read_output(id, "height"))

    def output_width(self, id: Optional[Id] = None) -> float | None:
        """
        Reactively read the width of an output.

        Parameters
        ----------
        id
            The id of the output.

        Returns
        -------
        float | None
            The width of the output, or None if the output does not exist (or does not
            report its width).
        """
        return cast(float, self._read_output(id, "width"))

    def output_hidden(self, id: Optional[Id] = None) -> bool | None:
        """
        Reactively read whether an output is hidden.

        Parameters
        ----------
        id
            The id of the output.

        Returns
        -------
        bool | None
            Whether the output is hidden, or None if the output does not exist.
        """
        return cast(bool, self._read_output(id, "hidden"))

    def output_bg_color(self, id: Optional[Id] = None) -> str | None:
        """
        Reactively read the background color of an output.

        Parameters
        ----------
        id
            The id of the output.

        Returns
        -------
        str | None
            The background color of the output, or None if the output does not exist (or
            does not report its bg color).
        """
        return cast(str, self._read_output(id, "bg"))

    def output_fg_color(self, id: Optional[Id] = None) -> str | None:
        """
        Reactively read the foreground color of an output.

        Parameters
        ----------
        id
            The id of the output.

        Returns
        -------
        str | None
            The foreground color of the output, or None if the output does not exist (or
            does not report its fg color).
        """
        return cast(str, self._read_output(id, "fg"))

    def output_accent_color(self, id: Optional[Id] = None) -> str | None:
        """
        Reactively read the accent color of an output.

        Parameters
        ----------
        id
            The id of the output.

        Returns
        -------
        str | None
            The accent color of the output, or None if the output does not exist (or
            does not report its accent color).
        """
        return cast(str, self._read_output(id, "accent"))

    def output_font(self, id: Optional[Id] = None) -> str | None:
        """
        Reactively read the font(s) of an output.

        Parameters
        ----------
        id
            The id of the output.

        Returns
        -------
        str | None
            The font family of the output, or None if the output does not exist (or
            does not report its font styles).
        """
        return cast(str, self._read_output(id, "font"))

    def _read_input(self, key: str) -> str:
        self._check_current_context(key)

        id = ResolvedId(f".clientdata_{key}")
        if id not in self._session.root_scope().input:
            raise ValueError(
                f"ClientData value '{key}' not found. Please report this issue."
            )

        val = self._session.root_scope().input[id]
        if val._name is None:
            # No leading `.`
            val._name = str(id).removeprefix(".")

        return val()

    def _read_output(self, id: Id | None, key: str) -> str | None:
        self._check_current_context(f"output_{key}")

        # No `id` provided support
        if id is None:
            id = _current_output_name.get()

        if id is None:
            raise ValueError(
                "session.clientdata.output_*() requires an id when not called within "
                "an output renderer."
            )

        # Module support
        non_namespace_id = id
        if not isinstance(id, ResolvedId):
            id = self._session.ns(id)

        input_id = ResolvedId(f".clientdata_output_{id}_{key}")
        if input_id in self._session.root_scope().input:
            val = self._session.root_scope().input[input_id]
            if val._name is None:
                # No leading `.`
                val._name = f"clientdata_output_{non_namespace_id}_{key}"
            return val()
        else:
            return None

    @contextlib.contextmanager
    def _output_name_ctx(self, output_name: ResolvedId) -> Generator[None, None, None]:
        """
        Context manager to temporarily set the output name.

        This is used to allow `session.clientdata.output_*()` methods to access the
        current output name without needing to pass it explicitly.
        """
        token = _current_output_name.set(output_name)
        try:
            yield
        finally:
            _current_output_name.reset(token)

    @staticmethod
    def _check_current_context(key: str) -> None:
        try:
            reactive.get_current_context()
        except RuntimeError:
            raise RuntimeError(
                f"session.clientdata.{key}() must be called from within a reactive context."
            )


# ======================================================================================
# Outputs
# ======================================================================================


@dataclasses.dataclass
class OutputInfo:
    renderer: Renderer[Any]
    effect: Effect_
    suspend_when_hidden: bool


class Outputs:
    """
    A class representing Shiny output definitions.
    """

    def __init__(
        self,
        session: Session,
        ns: Callable[[str], ResolvedId],
        *,
        outputs: dict[str, OutputInfo],
    ) -> None:
        self._session = session
        self._ns = ns
        self._outputs = outputs

    @overload
    def __call__(self, renderer: RendererT) -> RendererT:
        pass

    @overload
    def __call__(
        self,
        *,
        id: Optional[str] = None,
        suspend_when_hidden: bool = True,
        priority: int = 0,
    ) -> Callable[[RendererT], RendererT]:
        pass

    def __call__(
        self,
        renderer: Optional[RendererT] = None,
        *,
        id: Optional[str] = None,
        suspend_when_hidden: bool = True,
        priority: int = 0,
    ) -> RendererT | Callable[[RendererT], RendererT]:

        def require_real_session() -> Session:
            if self._session.is_stub_session():
                raise RuntimeError(
                    "`output` must be used with a real session (as opposed to a stub session)."
                )

            return self._session

        def set_renderer(renderer: RendererT) -> RendererT:
            if not isinstance(renderer, Renderer):
                raise TypeError(
                    "`@output` must be applied to a `@render.xx` function.\n"
                    + "In other words, `@output` must be above `@render.xx`."
                )

            # Get the (possibly namespaced) output id
            output_id = id or renderer.__name__
            output_name = self._ns(output_id)

            # renderer is a Renderer object. Give it a bit of metadata.
            renderer._set_output_metadata(output_id=output_id)

            # Gather otel info for inner method
            renderer_func = getattr(renderer.fn, "_orig_fn", renderer.fn)
            output_otel_label = create_otel_span_name(
                func=renderer_func,
                label_type="output",
                session=self._session,
            )
            output_otel_attrs = extract_source_ref(renderer_func)
            output_otel_level = resolve_func_otel_level(renderer_func)

            renderer._on_register()

            self.remove(output_name)

            @effect(
                suspended=suspend_when_hidden and self._session._is_hidden(output_name),
                priority=priority,
            )
            @otel_suppress
            async def output_obs():
                if self._session.is_stub_session():
                    raise RuntimeError(
                        "`output` must be used with a real session (as opposed to a stub session)."
                    )

                session = require_real_session()
                output_attrs = {
                    **get_session_id_attrs(session),
                    **output_otel_attrs,
                }

                await session._send_message(
                    {"recalculating": {"name": output_name, "status": "recalculating"}}
                )
                # Let the message go out before a synchronous renderer blocks the event
                # loop, so that the output's busy indicator shows. On Windows, a write
                # made while an earlier write is still in flight goes out only when the
                # loop runs again.
                # https://github.com/posit-dev/py-shiny/issues/1381
                await asyncio.sleep(0)

                try:
                    async with shiny_otel_span(
                        output_otel_label,
                        attributes=output_attrs,
                        infer_session_id=False,
                        required_level=OtelCollectLevel.REACTIVITY,
                        collection_level=output_otel_level,
                    ):
                        with session.clientdata._output_name_ctx(output_name):
                            # Call the app's renderer function
                            value = await renderer.render()

                    session._outbound_message_queues.set_value(output_name, value)

                except SilentOperationInProgressException:
                    session._send_progress(
                        "binding", {"id": output_name, "persistent": True}
                    )
                    # It's important to exit early here _without_ a recalculated message
                    return
                except SilentCancelOutputException:
                    pass
                except SilentException:
                    session._outbound_message_queues.set_silent(output_name)
                except Exception as e:
                    # Print traceback to the console
                    traceback.print_exc()
                    # Possibly sanitize error for the user
                    if session.app.sanitize_errors and not isinstance(e, SafeException):
                        err_msg = session.app.sanitize_error_msg
                    else:
                        err_msg = str(e)
                    # Register the outbound error message
                    err_message = {
                        "message": err_msg,
                        # TODO: is it possible to get the call?
                        "call": None,
                        # TODO: I don't think we actually use this for anything client-side
                        "type": None,
                    }
                    session._outbound_message_queues.set_error(
                        output_name,
                        err_message,
                        # Recorded only in test mode; never sent to the client.
                        traceback_text=traceback.format_exc(),
                    )

                await session._send_message(
                    {
                        "recalculating": {
                            "name": output_name,
                            "status": "recalculated",
                        }
                    }
                )

            output_obs.on_invalidate(
                lambda: require_real_session()._send_progress(
                    "binding", {"id": output_name}
                )
            )

            # Store the renderer and effect info
            self._outputs[output_name] = OutputInfo(
                renderer=renderer,
                effect=output_obs,
                suspend_when_hidden=suspend_when_hidden,
            )

            return renderer

        if renderer is None:
            return set_renderer
        else:
            return set_renderer(renderer)

    def remove(self, id: Id) -> None:
        output_name = self._ns(id)
        if output_name in self._outputs:
            self._outputs[output_name].effect.destroy()
            del self._outputs[output_name]

    def _destroy(self) -> None:
        # This will cause all modules with the same module namespace prefix to have their outputs removed.
        # So if one parent module is being torn down, all descendant modules will be torn down.
        # Just like with Inputs

        prefix = str(self._ns) + "-"
        keys_to_remove = [k for k in self._outputs if k.startswith(prefix)]
        for key in keys_to_remove:
            self._outputs[key].effect.destroy()
            del self._outputs[key]

    def _manage_hidden(self) -> None:
        "Suspends execution of hidden outputs and resumes execution of visible outputs."
        for name, output in self._outputs.items():
            if self._should_suspend(name):
                output.effect.suspend()
            else:
                output.effect.resume()

    def _should_suspend(self, name: str) -> bool:
        return self._outputs[name].suspend_when_hidden and self._session._is_hidden(
            name
        )
