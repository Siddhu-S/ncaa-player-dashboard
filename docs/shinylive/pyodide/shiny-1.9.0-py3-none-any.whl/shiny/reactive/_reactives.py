"""Reactive components"""

from __future__ import annotations

__all__ = (
    "value",
    "Value",
    "calc",
    "Calc",
    "Calc_",
    "CalcAsync_",
    "effect",
    "Effect",
    "Effect_",
    "event",
)

import asyncio
import functools
import traceback
import warnings
import weakref
from typing import (
    TYPE_CHECKING,
    Any,
    Awaitable,
    Callable,
    Generic,
    Optional,
    TypeVar,
    cast,
    overload,
)

from .. import _utils
from .._docstring import add_example
from .._utils import is_async_callable, run_coro_sync
from .._validation import req
from ..otel._attributes import SourceRefAttrs, extract_source_ref, get_session_id_attrs
from ..otel._collect import OtelCollectLevel, get_level
from ..otel._core import emit_otel_log, is_otel_tracing_enabled
from ..otel._function_attrs import resolve_func_otel_level
from ..otel._labels import (
    create_otel_label,
    create_otel_span_name,
    get_otel_label_modifier,
    set_otel_label_modifier,
)
from ..otel._span_wrappers import shiny_otel_span, use_otel_span
from ..types import (
    MISSING,
    MISSING_TYPE,
    ActionButtonValue,
    NotifyException,
    SilentException,
)
from ._core import Context, Dependents, ReactiveWarning, _enclosing_run, isolate
from ._utils import is_user_code_frame


def _current_task() -> Optional[asyncio.Task[object]]:
    try:
        return asyncio.current_task()
    except RuntimeError:
        # No running loop (a sync calc read outside of asyncio).
        return None


def _weak_destroy_callback(
    method: Callable[[], None],
    session: Session,
) -> Callable[[], None]:
    """
    Build the ``on_destroy`` callback that a reactive registers with its session.

    The bound method is wrapped in a ``weakref.WeakMethod`` so the callback does
    not prevent the owning reactive from being garbage collected. If the reactive
    has already been collected, the wrapper silently no-ops.

    The wrapper also no-ops when the session is closed. A whole-session close is
    not a destroy: every consumer in the session is already gone (effects are
    destroyed via ``on_ended``, and the session can no longer flush), so the
    reactive is left intact and reclaimed by ordinary garbage collection.
    Tearing it down here would instead poison async work that outlives the
    connection -- an :class:`~shiny.reactive.ExtendedTask` settling after a page
    refresh, an ``asyncio`` task, a ``loop.call_later()`` callback -- with an
    unavoidable, racy :class:`DestroyedReactiveError`.
    """
    ref = weakref.WeakMethod(method)

    def wrapper() -> None:
        if session._is_closed():
            return
        fn = ref()
        if fn is not None:
            fn()

    return wrapper


class DestroyedReactiveError(Exception):
    """Raised when accessing a destroyed reactive.calc."""

    pass


if TYPE_CHECKING:
    from .. import Session

T = TypeVar("T")


# ==============================================================================
# Value
# ==============================================================================
@add_example()
class Value(Generic[T]):
    """
    Create a reactive value.

    Reactive values are the source of reactivity in Shiny. Changes to reactive values
    invalidate downstream reactive functions (:func:`~shiny.reactive.calc`,
    :func:`~shiny.reactive.effect`, and `render` functions decorated with `@output`).
    When these functions are invalidated, they get scheduled to re-execute.

    Shiny input values are read-only reactive values. For example, `input.x` is a
    reactive value object, and to get the current value, you can call `input.x()` or
    `input.x.get()`. When you do that inside of a reactive function, the function takes
    a dependency on the reactive value.

    Parameters
    ----------
    value
        An optional initial value.
    read_only
        If ``True``, then the reactive value cannot be `set()`.
    name
        An optional name for the reactive value, used in OpenTelemetry logging and
        debugging. If not provided, the name will be automatically inferred from the
        assignment statement (e.g., ``counter = reactive.Value(0)`` will use "counter"
        as the name). If automatic inference fails, the name will be ``None`` and logs
        will show ``"<unnamed>"``. Input values created by Shiny will have their names
        set automatically based on their input IDs.

    Returns
    -------
    :
        An instance of a reactive value.

    Raises
    ------
    :class:`~shiny.types.SilentException`
        If :func:`~shiny.reactive.Value.get` is called before a value is provided/set.

    Note
    ----
    A reactive value may only be read from within a reactive function (e.g.,
    :func:`~shiny.reactive.calc`, :func:`~shiny.reactive.effect`,
    :class:`shiny.render.text`, etc.) and, when doing so, the function takes a reactive
    dependency on the value (i.e., when the value changes, the calling reactive function
    will re-execute).

    See Also
    --------
    * :class:`~shiny.Inputs`
    * :func:`~shiny.reactive.calc`
    * :func:`~shiny.reactive.effect`
    """

    # These overloads are necessary so that the following hold:
    # - Value() is marked by the type checker as an error, because the type T is
    #   unknown. (It is not a run-time error.)
    # - Value[int]() works.
    # - Value[int](1) works.
    # - Value(1) works, with T is inferred to be int.
    @overload
    def __init__(
        self,
        value: MISSING_TYPE = MISSING,
        *,
        read_only: bool = False,
        name: str | None = None,
    ) -> None: ...

    @overload
    def __init__(
        self, value: T, *, read_only: bool = False, name: str | None = None
    ) -> None: ...

    # If `value` is MISSING, then `get()` will raise a SilentException, until a new
    # value is set. Calling `unset()` will set the value to MISSING.
    def __init__(
        self,
        value: T | MISSING_TYPE = MISSING,
        *,
        read_only: bool = False,
        name: str | None = None,
    ) -> None:
        from ..session._utils import get_current_session

        self._value: T | MISSING_TYPE = value
        self._read_only: bool = read_only
        self._value_dependents: Dependents = Dependents()
        self._is_set_dependents: Dependents = Dependents()
        # Optional name for OpenTelemetry logging and debugging
        # Priority during initialization: 1) explicit name parameter, 2) inferred from assignment, 3) None
        # Can be overwritten later by Inputs class when value is added/accessed
        self._name: str | None
        if name is not None:
            self._name = name
        else:
            self._name = self._try_infer_name()

        # Capture collection level at initialization time
        # This determines whether value updates will emit OTel logs
        session = get_current_session()
        self._otel_level: OtelCollectLevel = get_level()
        self._otel_attrs: dict[str, Any] = {**get_session_id_attrs(session)}
        if read_only:
            self._otel_attrs["read-only"] = True

        self._otel_namespace: str | None = None
        if session is not None:
            ns_str = str(session.ns)
            if ns_str:  # Only use non-empty namespaces
                self._otel_namespace = ns_str
        # Lazily initialized OTel label for value updates; Allows for `_name` to be adjusted manually after init (ex: Inputs class)
        self._otel_label: str | None = None
        # Guards destroy() idempotency — _set(MISSING) should only run once
        # to avoid redundant invalidation of dependents.
        self._destroyed: bool = False

        if session is not None:
            # Unset the value on session/module destroy so dependents are
            # invalidated and the stored value is freed. (Not on session close --
            # see `_weak_destroy_callback`.)
            session.on_destroy(_weak_destroy_callback(self.destroy, session))

    def _try_infer_name(self) -> str | None:
        """
        Attempt to infer the variable name from the call stack.

        This examines the frame where Value() was instantiated and tries
        to parse the assignment statement to extract the variable name.

        Returns None if the name cannot be reliably determined.

        Examples of what works:
        - counter = reactive.Value(0) → "counter"
        - counter = reactive.value(0) → "counter"
        - counter = Value(0) → "counter"
        - counter = value(0) → "counter"
        - self.counter = reactive.Value(0) → "counter"
        - self.counter = reactive.value(0) → "counter"
        - self.counter = Value(0) → "counter"
        - self.counter = value(0) → "counter"
        - counter: reactive.Value[int] = reactive.Value(0) → "counter"
        - self._messages: reactive.Value[tuple[str, ...]] = reactive.Value(()) → "_messages"
        - Multiline assignments (Value call on continuation line):
          self._messages: reactive.Value[tuple[str, ...]] = (
              reactive.Value(())
          ) → "_messages"
        - Multiline type annotations:
          self._latest: reactive.Value[
              str | None
          ] = reactive.Value(None) → "_latest"

        Examples of what doesn't work (returns None):
        - values = [reactive.Value(0), reactive.Value(1)]
        - reactive.Value(0)  # No assignment
        - Complex expressions
        """
        import inspect
        import re

        try:
            # Walk up the stack: [0] = _try_infer_name, [1] = __init__, [2] = caller
            for frame_info in inspect.stack()[2:]:
                filename = frame_info.filename

                # Skip internal shiny code, keep user code
                if not is_user_code_frame(filename):
                    continue

                # Get the source line
                if frame_info.code_context:
                    line = frame_info.code_context[0].strip()

                    # Pattern 1: var_name = [reactive.]Value(...) or [reactive.]value(...)
                    # Also handles type annotations: var_name: Type = [reactive.]Value(...)
                    # [\[\(] at the end anchors to either a function call `Value(`
                    # or a generic subscript `Value[int](`, preventing matches
                    # against identifiers like ValueFactory or value2
                    match = re.match(
                        r"^(\w+)\s*(?::[^=]+)?\s*=\s*(?:reactive\.)?[Vv]alue\s*[\[\(]",
                        line,
                    )
                    if match:
                        return match.group(1)

                    # Pattern 2: self.var_name = [reactive.]Value(...) or [reactive.]value(...)
                    # Also handles type annotations: self.var_name: Type = [reactive.]Value(...)
                    # [\[\(] at the end anchors to either a function call `Value(`
                    # or a generic subscript `Value[int](`, preventing matches
                    # against identifiers like ValueFactory or value2
                    match = re.match(
                        r"^\w+\.(\w+)\s*(?::[^=]+)?\s*=\s*(?:reactive\.)?[Vv]alue\s*[\[\(]",
                        line,
                    )
                    if match:
                        return match.group(1)

                    # If the line is a bare Value/value call (e.g., from a
                    # multiline assignment where the target is on a previous
                    # line), look backwards in the source file for the
                    # assignment target.
                    if re.search(r"\b[Vv]alue\b", line):
                        name = self._try_infer_name_from_preceding_lines(
                            filename, frame_info.lineno
                        )
                        if name is not None:
                            return name
                        break
                    continue

                # Stop after first user code frame with no source context
                break

        except Exception:
            # If anything fails, silently return None
            pass

        return None

    @staticmethod
    def _try_infer_name_from_preceding_lines(filename: str, lineno: int) -> str | None:
        """
        Look at preceding source lines to find the assignment target for a
        multiline reactive.Value() assignment.

        Handles patterns like::

            self._messages: reactive.Value[tuple[str, ...]] = (
                reactive.Value(())
            )

        where the Value() call is on a continuation line.
        """
        import linecache
        import re

        # Collect preceding lines to find the assignment target.
        # This handles cases where the type annotation or assignment spans
        # multiple lines, e.g.:
        #   self._messages: reactive.Value[tuple[str, ...]] = (
        #       reactive.Value(())
        #   )
        # or:
        #   self._latest: reactive.Value[
        #       str | None
        #   ] = reactive.Value(None)
        for offset in range(1, 6):
            prev_line = linecache.getline(filename, lineno - offset).strip()
            if not prev_line:
                break

            # Look for: var_name = ... or var_name: ... (start of assignment)
            match = re.match(
                r"^(\w+)\s*[:=]",
                prev_line,
            )
            if match:
                return match.group(1)

            # Look for: self.var_name = ... or self.var_name: ...
            match = re.match(
                r"^\w+\.(\w+)\s*[:=]",
                prev_line,
            )
            if match:
                return match.group(1)

        return None

    def _extract_caller_source_ref(self) -> SourceRefAttrs:
        """
        Extract source reference attributes from the caller of _set().

        This captures where the value update originated (file, line, column,
        function), which is useful for debugging and tracing reactive value changes.

        Returns
        -------
        SourceRefAttrs
            Dictionary with code.file.path, code.line.number, code.column.number, and
            code.function.name keys. Returns empty dict if source information is
            unavailable.

        Notes
        -----
        Following OpenTelemetry semantic conventions for code attributes:
        - code.file.path: Full path to source file
        - code.line.number: Line number where _set() was called (1-indexed)
        - code.column.number: Column offset where _set() was called (0-indexed,
          Python 3.11+ only)
        - code.function.name: Function name containing the call

        The column.number attribute uses Python 3.11+ frame position information
        for accurate column offsets. On earlier Python versions, this attribute
        is omitted.

        This method walks the call stack to find the first frame outside
        the shiny package (excluding tests), which represents user code.
        """
        import inspect

        try:
            # Stack: [0] = _extract_caller_source_ref, [1] = _set, [2] = caller
            for frame_info in inspect.stack()[2:]:
                filename = frame_info.filename

                # Skip internal shiny code, keep user code
                if not is_user_code_frame(filename):
                    continue

                # Found a user code frame - extract attributes
                attrs: SourceRefAttrs = {}
                attrs["code.file.path"] = filename

                if frame_info.lineno:
                    attrs["code.line.number"] = frame_info.lineno

                # Extract column number using Python 3.11+ position info when available
                # Only include if we have accurate position information
                if hasattr(frame_info, "positions") and frame_info.positions:  # type: ignore[attr-defined]
                    # Python 3.11+ provides precise column offset via positions
                    if frame_info.positions.col_offset is not None:  # type: ignore[attr-defined]
                        attrs["code.column.number"] = frame_info.positions.col_offset  # type: ignore[typeddict-item, attr-defined]

                if frame_info.function:
                    attrs["code.function.name"] = frame_info.function

                return attrs

        except Exception:
            # If anything fails, silently return empty dict
            pass

        return {}

    def __call__(self) -> T:
        return self.get()

    def get(self) -> T:
        """
        Read the reactive value.

        Returns
        -------
        :
            A value.

        Raises
        ------
        DestroyedReactiveError
            If the value has been destroyed.
        :class:`~shiny.types.SilentException`
            If the value is not set.
        RuntimeError
            If called from outside a reactive function.
        """
        if self._destroyed:
            raise DestroyedReactiveError(
                f"Reactive value '{self._name}' has been destroyed."
            )

        self._value_dependents.register()

        if isinstance(self._value, MISSING_TYPE):
            raise SilentException

        return self._value

    def set(self, value: T) -> bool:
        """
        Set the reactive value to a new value.

        Parameters
        ----------
        value
            A value.

        Returns
        -------
        :
            ``True`` if the value was set to a different value and ``False`` otherwise.

        Raises
        ------
        DestroyedReactiveError
            If the value has been destroyed.
        RuntimeError
            If called on a read-only reactive value.

        Note
        ----
        Setting a new value schedules its dependents to re-run automatically,
        without a call to :func:`~shiny.reactive.flush`. Call ``set()`` from the thread
        running Shiny's event loop. From any other thread, hand the call to that loop
        with ``loop.call_soon_threadsafe(value.set, new_value)``. The reactive graph
        isn't safe to change from two threads at once, and calling ``set()`` directly
        from another thread can fail (e.g. when a session's effect depends on the
        value).
        """
        if self._destroyed:
            raise DestroyedReactiveError(
                f"Reactive value '{self._name}' has been destroyed."
            )
        if self._read_only:
            raise RuntimeError(
                "Can't set read-only Value. If you are trying to set an input value, use `update_xxx()` instead."
            )
        return self._set(value)

    # The ._set() method allows setting read-only Value objects. This is used when the
    # Value is part of a session.Inputs object, and the session wants to set it.
    def _set(self, value: T, *, force: bool = False) -> bool:
        if not force and self._value is value:
            return False

        if isinstance(self._value, MISSING_TYPE) != isinstance(value, MISSING_TYPE):
            self._is_set_dependents.invalidate()

        self._value = value
        self._value_dependents.invalidate()

        self._emit_otel_log()

        return True

    def _emit_otel_log(self) -> None:
        # Log value update for OpenTelemetry
        # Only log when:
        # 1. Tracing is enabled (OpenTelemetry SDK is configured)
        # 2. Collection level (captured at initialization) is REACTIVITY or higher
        # 3. A session is available. (Initial input.* and .clientdata_* do not have a session when they are set, so we won't log those initial values. However, updates will be logged, since they occur within a session context.)
        if not (
            is_otel_tracing_enabled()
            and self._otel_level >= OtelCollectLevel.REACTIVITY
        ):
            return

        from ..session._utils import get_current_session

        s = get_current_session()
        if s is None:
            # No session, therefore it is too early
            return

        if self._otel_label is None:
            # Lazily initialize the OTel label on first set, when we have the name available
            self._otel_label = create_otel_label(
                "Set reactive.value",
                self._name,
                namespace=self._otel_namespace,
            )

        # Build attributes dict with session ID and source reference
        # Skip source ref extraction for read-only values (inputs) since the
        # caller is always internal framework code (starlette/asyncio), not user code
        attrs: dict[str, Any] = {**self._otel_attrs}
        if not self._read_only:
            attrs.update(self._extract_caller_source_ref())

        emit_otel_log(
            self._otel_label,
            severity_text="INFO",
            attributes=attrs,
            infer_session_id=False,
        )

    def destroy(self) -> None:
        """
        Destroy this reactive value.

        Unsets the value, invalidating all dependents and freeing the stored
        value. Idempotent: calling ``destroy()`` more than once has no effect.
        Works on read-only values (e.g., input values).

        Note
        ----
        This method will only perform the minimum cleanup needed to
        release resources and invalidate dependents — the same work that
        would happen if this object were garbage collected.
        """
        if self._destroyed:
            return
        self._destroyed = True
        # Invalidate directly instead of calling _set(MISSING) because _set()
        # short-circuits when the value is already MISSING (identity check).
        self._value = MISSING  # type: ignore
        self._value_dependents.invalidate()
        self._is_set_dependents.invalidate()

    def unset(self) -> None:
        """
        Unset the reactive value.

        Returns
        -------
        :
            ``True`` if the value was set prior to this unsetting.
        """
        self.set(MISSING)  # type: ignore

    def is_set(self) -> bool:
        """
        Check if the reactive value is set.

        Returns ``False`` for destroyed values.

        Returns
        -------
        :
            ``True`` if the value is set, ``False`` otherwise.
        """
        if self._destroyed:
            return False

        self._is_set_dependents.register()
        return not isinstance(self._value, MISSING_TYPE)

    def freeze(self) -> None:
        """
        Freeze the reactive value.

        Freezing is equivalent to unsetting the value, but it does not invalidate
        dependents.

        Raises
        ------
        DestroyedReactiveError
            If the value has been destroyed.
        """
        if self._destroyed:
            raise DestroyedReactiveError(
                f"Reactive value '{self._name}' has been destroyed."
            )
        self._value = MISSING


value = Value

# ==============================================================================
# Calc
# ==============================================================================

CalcFunction = Callable[[], T]
CalcFunctionAsync = Callable[[], Awaitable[T]]


class Calc_(Generic[T]):
    """
    Mark a function as a reactive calculation.

    Warning
    -------
    Most users shouldn't use this class directly to initialize a reactive calculation
    (instead, use the :func:`~shiny.reactive.calc` decorator).
    """

    def __init__(
        self,
        fn: CalcFunction[T],
        *,
        session: "MISSING_TYPE | Session | None" = MISSING,
    ) -> None:
        _utils.validate_no_params(fn, "reactive.calc", stacklevel=5)

        self.__name__ = fn.__name__
        self.__doc__ = fn.__doc__

        # The CalcAsync subclass will pass in an async function, but it tells the
        # static type checker that it's synchronous. wrap_async() is smart -- if is
        # passed an async function, it will not change it.
        self._fn: CalcFunctionAsync[T] = _utils.wrap_async(fn)
        self._is_async: bool = _utils.is_async_callable(fn)

        self._dependents: Dependents = Dependents()
        self._invalidated: bool = True
        self._running: bool = False
        # The task running `update_value()`, and readers from other tasks waiting on
        # that run (async calcs only: concurrent effects can read mid-run).
        self._running_task: Optional[asyncio.Task[object]] = None
        self._run_waiters: list[asyncio.Future[None]] = []
        self._most_recent_ctx_id: int = -1
        # How many runs of the most recent run's task are in progress: more than
        # one when the calc reads itself.
        self._run_depth: int = 0
        self._ctx: Optional[Context] = None
        self._exec_count: int = 0
        # Guards destroy() idempotency and __call__/get_value access.
        # Once destroyed, the calc raises DestroyedReactiveError on access.
        self._destroyed: bool = False

        self._session: Optional[Session]
        # Use `isinstance(x, MISSING_TYPE)`` instead of `x is MISSING` because
        # the type checker doesn't know that MISSING is the only instance of
        # MISSING_TYPE; this saves us from casting later on.
        if isinstance(session, MISSING_TYPE):
            from ..session import get_current_session

            # If no session is provided, autodetect the current session (this
            # could be None if outside of a session).
            session = get_current_session()
        self._session = session

        # Use lists to hold (optional) value and error, instead of Optional[T],
        # because it makes typing more straightforward. For example if
        # .get_value() simply returned self._value, self._value had type
        # Optional[T], then the return type for get_value() would have to be
        # Optional[T].
        self._value: list[T] = []
        self._error: list[Exception] = []

        # Extract OpenTelemetry attributes at initialization time
        self._otel_attrs = {
            **self._extract_otel_attrs(fn),
            **get_session_id_attrs(session),
        }

        # Extract modifier from function attribute and generate label
        self._otel_label: str = create_otel_span_name(
            fn,
            "reactive.calc",
            session=self._session,
            modifier=get_otel_label_modifier(fn),
        )

        # Extract collection level from function attributes (set by shiny.otel
        # decorators like @otel.suppress and @otel.collect). If not set, capture
        # the current collection level at initialization time.
        self._otel_level: OtelCollectLevel = resolve_func_otel_level(fn)

        if self._session is not None:
            # Invalidate context and dependents on session/module destroy so
            # the calc is permanently destroyed and references are freed. (Not on
            # session close -- see `_weak_destroy_callback`.)
            self._session.on_destroy(
                _weak_destroy_callback(self.destroy, self._session)
            )

    def destroy(self) -> None:
        """
        Destroy this reactive calc.

        Invalidates the calc's context and all downstream dependents, freeing
        references. After destruction, calling the calc raises
        :class:`DestroyedReactiveError`. Idempotent.

        Note
        ----
        This method will only perform the minimum cleanup needed to
        release resources and invalidate dependents — the same work that
        would happen if this object were garbage collected.
        """
        if self._destroyed:
            return
        self._destroyed = True
        if self._ctx is not None:
            # _on_invalidate_cb handles clearing _value, invalidating
            # _dependents, and setting _ctx = None.
            self._ctx.invalidate()
        else:
            # Calc was never evaluated, so no context exists and
            # _on_invalidate_cb won't fire. Clean up manually.
            self._dependents.invalidate()
            self._value.clear()
        self._error.clear()

    def __call__(self) -> T:
        if self._destroyed:
            raise DestroyedReactiveError(
                f"Reactive calc '{self._otel_label}' has been destroyed."
            )
        # Run the Coroutine (synchronously), and then return the value.
        # If the Coroutine yields control, then an error will be raised.
        return _utils.run_coro_sync(self.get_value())

    # TODO: should this be private?
    async def get_value(self) -> T:
        if self._destroyed:
            raise DestroyedReactiveError(
                f"Reactive calc '{self._otel_label}' has been destroyed."
            )
        self._dependents.register()

        # Another task is computing this value: share that run rather than starting a
        # second one. Recompute only if it was invalidated meanwhile.
        current = _current_task()
        while (
            self._running
            and not self._invalidated
            and self._running_task is not current
        ):
            waiter: asyncio.Future[None] = asyncio.get_running_loop().create_future()
            self._run_waiters.append(waiter)
            await waiter

        if self._invalidated or self._running:
            value, error = await self._update_value()
            if error:
                raise error[0]
            return value[0]

        if self._error:
            raise self._error[0]

        return self._value[0]

    # TODO: should this be private?
    async def update_value(self) -> None:
        await self._update_value()

    async def _update_value(self) -> tuple[list[T], list[Exception]]:
        """
        Run the calc; return this run's value or error.

        Only the most recent run is cached: an async run can be invalidated and
        superseded by a newer one while it awaits.
        """
        ctx = Context()
        self._ctx = ctx
        # A nested run (the calc reading itself, in the same task) belongs to the
        # run that started it: only the outermost one writes the cache.
        nested = self._running and self._running_task is _current_task()
        if not nested:
            self._most_recent_ctx_id = ctx.id
            self._run_depth = 0
        run_id = self._most_recent_ctx_id
        self._run_depth += 1

        def on_invalidate() -> None:
            # A superseded run (e.g. a cancelled one) stays subscribed to what it
            # read; only the most recent run's sources (including its nested runs')
            # should invalidate the calc.
            if run_id == self._most_recent_ctx_id:
                self._on_invalidate_cb()

        ctx.on_invalidate(on_invalidate)

        self._exec_count += 1
        self._invalidated = False

        self._running = True
        self._running_task = _current_task()
        value: list[T] = []
        error: list[Exception] = []

        from ..session import session_context

        with session_context(self._session):
            async with shiny_otel_span(
                self._otel_label,
                attributes=self._otel_attrs,
                infer_session_id=False,
                required_level=OtelCollectLevel.REACTIVITY,
                collection_level=self._otel_level,
            ):
                try:
                    with ctx():
                        try:
                            value.append(await self._fn())
                        except Exception as err:
                            error.append(err)
                finally:
                    if run_id == self._most_recent_ctx_id:
                        self._run_depth -= 1
                    if run_id == self._most_recent_ctx_id and self._run_depth == 0:
                        # If this run was invalidated meanwhile, `_invalidated` makes
                        # the next read recompute anyway.
                        self._value[:] = value
                        self._error[:] = error
                        if not value and not error:
                            # Cancelled before it finished: there's nothing to cache,
                            # so the next read (or a waiting one) recomputes.
                            self._invalidated = True
                        self._running = False
                        self._running_task = None
                        waiters = self._run_waiters
                        self._run_waiters = []
                        for waiter in waiters:
                            if not waiter.done():
                                waiter.set_result(None)
        return value, error

    def _on_invalidate_cb(self) -> None:
        self._invalidated = True
        self._value.clear()  # Allow old value to be GC'd
        self._dependents.invalidate()
        self._ctx = None  # Allow context to be GC'd

    def _extract_otel_attrs(self, fn: Callable[..., Any]) -> SourceRefAttrs:
        """Extract OpenTelemetry attributes from the reactive function."""
        return extract_source_ref(fn)


class CalcAsync_(Calc_[T]):
    """
    Mark an async function as a reactive calculation.

    Warning
    -------
    Most users shouldn't use this class directly to initialize a reactive calculation
    (instead, use the :func:`~shiny.reactive.calc` decorator).
    """

    def __init__(
        self,
        fn: CalcFunctionAsync[T],
        *,
        session: "MISSING_TYPE | Session | None" = MISSING,
    ) -> None:
        if not _utils.is_async_callable(fn):
            raise TypeError(self.__class__.__name__ + " requires an async function")

        super().__init__(cast(CalcFunction[T], fn), session=session)

    async def __call__(self) -> T:  # pyright: ignore[reportIncompatibleMethodOverride]
        return await self.get_value()


@overload
def calc(fn: CalcFunctionAsync[T]) -> CalcAsync_[T]: ...


@overload
def calc(fn: CalcFunction[T]) -> Calc_[T]: ...


# Note that the specified return type of this Calc() overload (with a `session`) isn't
# exactly the same as the actual returned object -- the specified return type is a
# Callable that takes a CalcFunction[T], and actual return type is a Callable that takes
# CalcFunction[T] | CalcFunctionAsync[T]. Both are technically correct, since the
# CalcFunction's T encompasses both "regular" types V as well as Awatiable[V]. (We're
# using V to represent a generic type that is NOT itself Awaitable.) So if the T
# represents an Awaitable[V], then the type checker knows that the returned function
# will return a Calc[Awaitable[V]].
#
# However, if the Calc() function is specified to return a Callable that takes
# CalcFunction[T] | CalcFunctionAsync[T], then if a CalcFunctionAsync is passed in, the
# type check will not know that the returned Calc object is a Calc[Awaitable[V]]. It
# will think that it's a [Calc[V]]. Then the type checker will think that the returned
# Calc object is not async when it actually is.
#
# To work around this, we say that Calc() returns a Callable that takes a
# CalcFunction[T], instead of the union type. We're sort of tricking the type checker
# twice: once here, and once when we return a Calc object (which has a synchronous
# __call__ method) or CalcAsync object (which has an async __call__ method), and it
# works out.
@overload
def calc(
    *, session: "MISSING_TYPE | Session | None" = MISSING
) -> Callable[[CalcFunction[T]], Calc_[T]]: ...


@add_example()
def calc(
    fn: Optional[CalcFunction[T] | CalcFunctionAsync[T]] = None,
    *,
    session: "MISSING_TYPE | Session | None" = MISSING,
) -> Calc_[T] | Callable[[CalcFunction[T]], Calc_[T]]:
    """
    Mark a function as a reactive calculation.

    A reactive calculation is a function whose return value depends on other
    reactive value(s) (i.e., :class:`~shiny.Inputs`, :class:`~shiny.reactive.Value`s,
    and other reactive calculations). Whenever a reactive value changes, any reactive
    calculations that depend on it are "invalidated" and automatically re-execute if called while invalid. If a reactive calculation is marked as invalidated, any other reactive
    calculations that recently called it are also marked as invalidated. In this way,
    invalidations ripple through reactive calculations that depend on each other.

    Parameters
    ----------
    session
        A :class:`~shiny.Session` instance. If not provided, the session is inferred via
        :func:`~shiny.session.get_current_session`.

    Returns
    -------
    :
        A decorator that marks a function as a reactive calculation.

    Tip
    ---
    Reactive calculations should not produce any side effects; to reactively produce
    side effects, use :func:`~shiny.reactive.effect` instead.

    Reactive calculations are analagous to reactive expressions in Shiny for R.

    See Also
    --------
    * :class:`~shiny.Inputs`
    * :class:`~shiny.reactive.Value`
    * :func:`~shiny.reactive.effect`
    * :func:`~shiny.reactive.invalidate_later`
    * :func:`~shiny.reactive.event`
    """

    def create_calc(fn: CalcFunction[T] | CalcFunctionAsync[T]) -> Calc_[T]:
        if _utils.is_async_callable(fn):
            return CalcAsync_(fn, session=session)
        else:
            fn = cast(CalcFunction[T], fn)
            return Calc_(fn, session=session)

    if fn is None:
        return create_calc
    else:
        return create_calc(fn)


# Alias for backward compatibility
Calc = calc

# ==============================================================================
# Effect
# ==============================================================================

EffectFunction = Callable[[], None]
EffectFunctionAsync = Callable[[], Awaitable[None]]


class Effect_:
    """
    Mark a function as a reactive side effect.

    Warning
    -------
    Most users shouldn't use this class directly to initialize a reactive side effect
    (instead, use the :func:`Effect` decorator).
    """

    def __init__(
        self,
        fn: EffectFunction | EffectFunctionAsync,
        *,
        suspended: bool = False,
        priority: int = 0,
        session: "MISSING_TYPE | Session | None" = MISSING,
    ) -> None:
        self.__name__ = fn.__name__
        self.__doc__ = fn.__doc__

        from ..render.renderer import Renderer
        from ..session import Session
        from ..session._session import AppSession, SessionProxy

        if isinstance(fn, Renderer):
            raise TypeError(
                "`@reactive.effect` can not be combined with `@render.xx`.\n"
                + "Please remove your call of `@reactive.effect`."
            )

        _utils.validate_no_params(fn, "reactive.effect", stacklevel=5)

        # The EffectAsync subclass will pass in an async function, but it tells the
        # static type checker that it's synchronous. wrap_async() is smart -- if is
        # passed an async function, it will not change it.
        self._fn: EffectFunctionAsync = _utils.wrap_async(fn)
        # This indicates whether the user's effect function (before wrapping) is async.
        self._is_async: bool = _utils.is_async_callable(fn)

        self._priority: int = priority
        self._suspended = suspended
        self._on_resume: Callable[[], None] = lambda: None
        # Resolved when the latest run finishes (see `on_flush_cb`).
        self._run_done: Optional[asyncio.Future[None]] = None
        # Tasks running (or waiting to run) this effect; `destroy()` cancels them.
        self._run_tasks: set[asyncio.Task[object]] = set()

        self._invalidate_callbacks: list[Callable[[], None]] = []
        self._destroyed: bool = False
        self._ctx: Optional[Context] = None
        self._exec_count: int = 0

        self._session: Optional[Session]
        # Use `isinstance(x, MISSING_TYPE)`` instead of `x is MISSING` because
        # the type checker doesn't know that MISSING is the only instance of
        # MISSING_TYPE; this saves us from casting later on.
        if isinstance(session, MISSING_TYPE):
            from ..session import get_current_session

            # If no session is provided, autodetect the current session (this
            # could be None if outside of a session).
            session = get_current_session()

        if isinstance(session, Session) and session.is_stub_session():
            # If we're in an ExpressStubSession or a SessionProxy of one, then don't
            # actually set up this effect -- we don't want it to try to run later.
            return

        self._session = session

        if self._session is not None:
            # TODO-future: Investigate using a weak reference for on_ended too.
            # Currently kept as a strong reference to preserve existing behavior
            # where effects are guaranteed to be destroyed at session end. That
            # `on_ended` registration is also what destroys effects on session
            # close, since the `on_destroy` one no-ops there.
            self._session.on_ended(self.destroy)
            # Before the scope's other destroy callbacks: an async one that yields
            # would otherwise let a run of this effect resume and read a value the
            # scope has already destroyed.
            destroy_fn = _weak_destroy_callback(self.destroy, self._session)
            root = (
                self._session.root_scope()
                if isinstance(self._session, SessionProxy)
                else self._session
            )
            if isinstance(root, AppSession):
                root._register_destroy(destroy_fn, ns=str(self._session.ns), first=True)
            else:
                # Intentional, not a gap to fix: `_register_destroy()` is kept off
                # the public `Session` API, so other sessions (duck-typed test
                # mocks with no `root_scope()`, third-party `Session` subclasses)
                # get plain `on_destroy()` ordering.
                self._session.on_destroy(destroy_fn)

        # Extract OpenTelemetry attributes at initialization time
        self._otel_attrs: dict[str, Any] = {
            **get_session_id_attrs(self._session),
            **self._extract_otel_attrs(fn),
        }

        # Extract modifier from function attribute and generate label
        self._otel_label: str = create_otel_span_name(
            fn,
            "reactive.effect",
            session=self._session,
            modifier=get_otel_label_modifier(fn),
        )

        # Extract collection level from function attribute (e.g., set by `@otel.suppress` or `@otel.collect` decorators)
        self._otel_level: OtelCollectLevel = resolve_func_otel_level(fn)

        # Defer the first run to the next round
        self._create_context().invalidate()

    def _create_context(self) -> Context:
        ctx = Context()

        # Store the context explicitly in Effect object
        # TODO: More explanation here
        self._ctx = ctx
        # The priority this context's run was queued at; `set_priority()` doesn't
        # change it.
        queued_priority = self._priority

        def on_invalidate_cb() -> None:
            # Context is invalidated, so we don't need to store a reference to it
            # anymore.
            self._ctx = None

            for cb in self._invalidate_callbacks:
                cb()

            if self._destroyed:
                return

            def _continue() -> None:
                nonlocal queued_priority
                queued_priority = self._priority
                ctx.add_pending_flush(queued_priority)
                if self._session:
                    self._session._increment_busy_count()

            if self._suspended:
                self._on_resume = _continue
            else:
                _continue()

        async def on_flush_cb() -> None:
            # Unlike R, runs of one effect don't overlap: a re-run waits for the
            # previous run's async part, so a slower, older run can't finish last.
            previous = self._run_done
            done: asyncio.Future[None] = asyncio.get_running_loop().create_future()
            self._run_done = done
            task = _current_task()
            if task is not None:
                self._run_tasks.add(task)
            try:
                if previous is not None and not previous.done():
                    await asyncio.shield(previous)
                # While the session restores its bookmarked state, wait for the
                # `on_restore` callbacks to finish. Not once destroyed: the session
                # may have ended before its restore effect ran, in which case the
                # gate never opens.
                restore = (
                    self._session._restore_gate(queued_priority)
                    if self._session and not self._destroyed
                    else None
                )
                if restore is not None and not restore.done():
                    await asyncio.shield(restore)
                if not self._destroyed:
                    await self._run()
            except Exception as e:
                # The effect runs in its own task, so report errors to its session.
                if not self._session:
                    raise
                # `_unhandled_error()` prints only the message; show where it failed.
                traceback.print_exception(type(e), e, e.__traceback__)
                await self._session._unhandled_error(e)
            finally:
                if task is not None:
                    self._run_tasks.discard(task)
                done.set_result(None)
                # Every exit path (raised, cancelled) must end the busy period.
                if self._session:
                    self._session._decrement_busy_count()

        ctx.on_invalidate(on_invalidate_cb)
        ctx.on_flush(on_flush_cb)

        return ctx

    async def _run(self) -> None:
        ctx = self._create_context()
        self._exec_count += 1

        from ..session import session_context

        # Run in the session's cycle span, so this effect's span (and those of the
        # calcs it reads) are its children.
        cycle_span = (
            self._session._otel_reactive_update_span() if self._session else None
        )
        with session_context(self._session), use_otel_span(cycle_span):
            async with shiny_otel_span(
                self._otel_label,
                attributes=self._otel_attrs,
                infer_session_id=False,
                required_level=OtelCollectLevel.REACTIVITY,
                collection_level=self._otel_level,
            ):
                try:
                    with ctx():
                        await self._fn()

                        # Yield so that messages can be sent to the client if necessary.
                        # https://github.com/posit-dev/py-shiny/issues/1381
                        await asyncio.sleep(0)

                except SilentException:
                    # It's OK for SilentException to cause an Effect to stop running
                    pass
                except NotifyException as e:
                    traceback.print_exc()

                    if self._session:
                        from .._app import SANITIZE_ERROR_MSG
                        from ..ui import notification_show

                        msg = str(e)
                        warnings.warn(msg, ReactiveWarning, stacklevel=2)
                        if e.sanitize:
                            msg = SANITIZE_ERROR_MSG
                        notification_show(msg, type="error", duration=None)
                        # As below: a destroyed effect has no session to close.
                        if e.close and not self._destroyed:
                            await self._session._unhandled_error(e)
                except Exception as e:
                    traceback.print_exc()

                    warnings.warn(
                        "Error in Effect: " + str(e), ReactiveWarning, stacklevel=2
                    )
                    # A destroyed effect has no session to protect. (E.g. cleanup
                    # in a cancelled run reads its destroyed scope's values.)
                    if self._session and not self._destroyed:
                        await self._session._unhandled_error(e)

    def on_invalidate(self, callback: Callable[[], None]) -> None:
        """
        Register a callback that will be called when this reactive effect is
        invalidated.

        Parameters
        ----------
        callback
            A callback that will be called when this reactive effect is invalidated.
        """
        self._invalidate_callbacks.append(callback)

    def destroy(self) -> None:
        """
        Destroy this reactive effect.

        Stops the effect from executing ever again, even if it is currently scheduled
        for re-execution. A run that is still in progress (e.g., paused at an `await`)
        is cancelled: `asyncio.CancelledError` is raised at its current `await`, so
        its `finally` blocks run but the rest of its body doesn't. The exception is
        the run that calls `destroy()` (directly, or from a task it started), as when
        an effect closes its own session; that run continues.

        An error raised by an effect after it has been destroyed is logged rather
        than closing the session. (E.g., cleanup in a cancelled run that reads its
        destroyed scope's values raises `DestroyedReactiveError`.)

        Effects are destroyed when their session ends, and when their scope is
        destroyed with :meth:`~shiny.Session.destroy`, so both cancel the effect's
        in-progress runs. Cancellation is delivered on the next pass of the event
        loop, so a cancelled run's cleanup runs after the session's ``on_ended``
        and the scope's ``on_destroy`` callbacks have run (unless one of them
        awaits).

        Note
        ----
        This method will only perform the minimum cleanup needed to
        release resources and prevent future execution — the same work
        that would happen if this object were garbage collected.
        """
        # Idempotent: a session registers `destroy` for both its end and its
        # destroy, and a second cancel would interrupt a cancelled run's cleanup.
        if self._destroyed:
            return
        self._destroyed = True

        # Cancel in-progress runs now, before the caller tears down what they read
        # (e.g. a destroyed scope's values). Skip the run calling us, so it finishes.
        caller = _enclosing_run.get()
        for task in self._run_tasks:
            if task is not caller:
                task.cancel()

        if self._ctx is not None:
            self._ctx.invalidate()

    def suspend(self) -> None:
        """
        Suspend the effect.

        Stops adding the effect to the reactive effect queue in response to
        invalidations. If the effect was invalidated prior to this call but it has not
        re-executed yet (because it waits for the next round), then that re-execution
        will still occur, because the effect is already in the queue.
        """
        self._suspended = True

    def resume(self) -> None:
        """
        Resume the effect.

        Causes this effect to start re-executing in response to invalidations. If the
        effect was invalidated while suspended, then it adds itself to the reactive
        effect queue, to re-execute in the next round.
        """
        if self._suspended:
            self._suspended = False
            self._on_resume()
            self._on_resume = lambda: None

    def set_priority(self, priority: int = 0) -> None:
        """
        Control the execution priority for this effect.

        Parameters
        ----------
        priority
            The new priority. A higher value means higher priority: an effect with a
            higher priority value starts before all effects with lower priority
            values. An async effect's awaited part doesn't hold back lower-priority
            effects, so they can finish first. Positive, negative, and zero values
            are allowed.

        Note
        ----
        If the effect is currently invalidated, then the change in priority will not
        take effect until the next invalidation--unless the effect is also currently
        suspended, in which case the priority change will be effective upon resume.
        """
        self._priority = priority

    def _extract_otel_attrs(self, fn: Callable[..., Any]) -> SourceRefAttrs:
        """Extract OpenTelemetry attributes from the reactive function."""
        return extract_source_ref(fn)


@overload
def effect(fn: EffectFunction | EffectFunctionAsync) -> Effect_: ...


@overload
def effect(
    *,
    suspended: bool = False,
    priority: int = 0,
    session: "MISSING_TYPE | Session | None" = MISSING,
) -> Callable[[EffectFunction | EffectFunctionAsync], Effect_]: ...


@add_example()
def effect(
    fn: Optional[EffectFunction | EffectFunctionAsync] = None,
    *,
    suspended: bool = False,
    priority: int = 0,
    session: "MISSING_TYPE | Session | None" = MISSING,
) -> Effect_ | Callable[[EffectFunction | EffectFunctionAsync], Effect_]:
    """
    Mark a function as a reactive side effect.

    A reactive effect is like a reactive calculation (:func:`~shiny.reactive.calc`) in
    that it can read reactive values and call reactive calculations, and will
    automatically re-execute when those dependencies change. But unlike reactive
    calculations, it doesn't return a result and can't be used as an input to other
    reactive expressions. Thus, reactive effects are only useful for their side effects (for
    example, performing I/O).

    Another contrast between reactive calculations and effects is their execution
    strategy. Reactive calculations use lazy evaluation; that is, when their
    dependencies change, they don't re-execute right away but rather wait until they are
    called by someone else. Indeed, if they are not called, then they will never
    re-execute. In contrast, effects use eager evaluation; as soon as their dependencies
    change, they schedule themselves to re-execute.

    Parameters
    ----------
    suspended
        If ``TRUE``, start the effect in a suspended state (i.e., it will not execute
        until resumed and invalidated).
    priority
        The new priority. A higher value means higher priority: an effect with a higher
        priority value starts before all effects with lower priority values. An async
        effect's awaited part doesn't hold back lower-priority effects, so they can
        finish first. Positive, negative, and zero values are allowed.
    session
        A :class:`~shiny.Session` instance. If not provided, the session is inferred via
        :func:`~shiny.session.get_current_session`.

    Returns
    -------
    :
        A decorator that marks a function as a reactive effect (:class:`Effect_`).

    Tip
    ---
    Reactive effects are analagous to observers in Shiny for R.

    See Also
    --------
    * :class:`~shiny.Inputs`
    * :class:`~shiny.reactive.Value`
    * :func:`~shiny.reactive.effect`
    * :func:`~shiny.reactive.invalidate_later`
    * :func:`~shiny.reactive.event`
    """

    def create_effect(fn: EffectFunction | EffectFunctionAsync) -> Effect_:
        fn = cast(EffectFunction, fn)
        return Effect_(fn, suspended=suspended, priority=priority, session=session)

    if fn is None:
        return create_effect
    else:
        return create_effect(fn)


Effect = effect


# ==============================================================================
# event decorator
# ==============================================================================
@add_example()
def event(
    *args: Callable[[], object] | Callable[[], Awaitable[object]],
    ignore_none: bool = True,
    ignore_init: bool = False,
) -> Callable[[Callable[[], T]], Callable[[], T]]:
    """
    Mark a function to react only when an "event" occurs.

    Shiny's reactive programming framework is primarily designed for calculated values
    (:func:`~shiny.reactive.calc`) and side-effect-causing actions
    (:func:`~shiny.reactive.effect`) that respond to **any** of their inputs changing.
    That's often what is desired in Shiny apps, but not always: sometimes you want to
    wait for a specific action to be taken from the user, like clicking an
    :func:`~shiny.ui.input_action_button`, before calculating or taking an action. You
    do not want the calculation or action to be prematurely triggered if other reactive
    values that it calls are invalidated. The reactive value (or function) which triggers
    other calculations or actions in this way is called an event.

    These situations demand a more imperative, "event handling" style of programming,
    which ``@reactive.event()`` provides. It does this by using the
    :func:`~shiny.reactive.isolate` primitive under-the-hood to essentially "limit" the
    set of reactive dependencies to those in ``args``. In other words, the event can call
    as many reactive values as it likes in its code body without taking a reactive
    dependency on them; it will be invalidated only when a dependency listed in args is
    invalidated.

    Parameters
    ----------
    *args
        One or more callables that represent the event; most likely this will be a
        reactive input value linked to a :func:`~shiny.ui.input_action_button` or
        similar (e.g., ``input.click``), but it can also be a (reactive or non-reactive)
        function that returns a value.
    ignore_none
        Whether to ignore the event if the value is ``None`` or ``0``.
    ignore_init
        If ``False``, the event triggers on the first run.

    Returns
    -------
    :
        A decorator that marks a function as an event handler.

    Tip
    ----
    This decorator must be applied before the relevant reactivity decorator (i.e.,
    ``@reactive.event`` must be applied before ``@reactive.effect``, ``@reactive.calc``,
    ``@render.ui``, etc).
    """

    if any([not callable(arg) for arg in args]):
        raise TypeError(
            "All objects passed to event decorator must be callable.\n"
            + "If you are calling `@reactive.event(f())`, try calling `@reactive.event(f)` instead."
        )

    if len(args) == 0:
        raise TypeError(
            "`@reactive.event()` requires at least one argument, as in `@reactive.event(input.x)`.\n"
        )

    def decorator(user_fn: Callable[[], T]) -> Callable[[], T]:
        if not callable(user_fn):
            raise TypeError(
                "`@reactive.event()` must be applied to a function or Callable object.\n"
                + "It should usually be applied before `@Calc`,` @Effect`, or `@render.xx` function.\n"
                + "In other words, `@reactive.event()` goes below the other decorators."
            )

        _utils.validate_no_params(user_fn, "reactive.event", stacklevel=3)

        if isinstance(user_fn, Calc_):
            raise TypeError(
                "`@reactive.event()` must be applied before `@reactive.calc`.\n"
                + "In other words, `@reactive.calc` must be above `@reactive.event()`."
            )

        # This is here instead of at the top of the .py file in order to avoid a
        # circular dependency.
        from ..render.renderer import Renderer

        if isinstance(user_fn, Renderer):
            # At some point in the future, we may allow this condition, if we find an
            # use case. For now we'll disallow it, for simplicity.
            raise TypeError(
                "`@reactive.event()` must be applied before `@render.xx` .\n"
                + "In other words, `@render.xx` must be above `@reactive.event()`."
            )

        initialized = False

        async def trigger() -> None:
            vals: list[object] = []
            for arg in args:
                if is_async_callable(arg):
                    v = await arg()
                else:
                    v = arg()
                vals.append(v)

            nonlocal initialized
            if ignore_init and not initialized:
                initialized = True
                req(False)
            if ignore_none and all(map(_is_none_event, vals)):
                req(False)

        if is_async_callable(user_fn):

            @functools.wraps(user_fn)
            # Impossible to specify a return type here; we know T is
            # Awaitable[something] but I don't think there's a way to refer to the
            # `something`
            async def new_user_async_fn():
                await trigger()
                with isolate():
                    return await user_fn()

            # Prepend "event" modifier to any existing label
            set_otel_label_modifier(new_user_async_fn, "event", mode="prepend")

            return new_user_async_fn  # type: ignore

        elif any([is_async_callable(arg) for arg in args]):
            raise TypeError(
                "When decorating a synchronous function with @reactive.event(), all"
                + "arguments to @reactive.event() must be synchronous functions."
            )

        else:

            @functools.wraps(user_fn)
            def new_user_fn() -> T:
                run_coro_sync(trigger())
                with isolate():
                    return user_fn()

            # Prepend "event" modifier to any existing label
            set_otel_label_modifier(new_user_fn, "event", mode="prepend")

            return new_user_fn

    return decorator


def _is_none_event(val: object) -> bool:
    return val is None or (isinstance(val, ActionButtonValue) and val == 0)


# The code below is a test that the type checker is correctly inferring types. It should
# have some type errors as indicated. There doesn't seem to be a good way to run pyright
# and expect errors. Until that's supported, the best thing to do is uncomment the code
# below and check that the errors are highlighted in red as expected. See:
# https://github.com/microsoft/pyright/discussions/2163

# # fmt: off
# def test_calc():
#     @Calc(session=MISSING)
#     async def fas() -> int:
#         return 1

#     @Calc(session=MISSING)
#     def fs() -> int:
#         return 1

#     @Calc
#     async def fa() -> int:
#         return 1

#     @Calc
#     def f() -> int:
#         return 1

#     def test():
#         await fas()  # Should error
#         await fs()   # Should error
#         await fa()   # Should error
#         await f()    # Should error

#         fas()        # Should error
#         fs()
#         fa()         # Should error
#         f()

#     async def test_async():
#         await fas()
#         await fs()   # Should error
#         await fa()
#         await f()    # Should error

#         fas()        # Should error
#         fs()
#         fa()         # Should error
#         f()

# # fmt: off
# def test_event():
#     @event()
#     async def fas() -> int:
#         return 1

#     @event()
#     def fs() -> int:
#         return 1

#     @event()
#     async def fa() -> int:
#         return 1

#     @event()
#     def f() -> int:
#         return 1

#     def test():
#         await fas()  # Should error
#         await fs()   # Should error
#         await fa()   # Should error
#         await f()    # Should error

#         fas()        # Should error
#         fs()
#         fa()         # Should error
#         f()

#     async def test_async():
#         await fas()
#         await fs()   # Should error
#         await fa()
#         await f()    # Should error

#         fas()        # Should error
#         fs()
#         fa()         # Should error
#         f()
